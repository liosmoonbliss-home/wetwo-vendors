/***********************************************************************
 * WeTwo — Coupon Management API
 * /api/coupons/manage
 *
 * Actions:
 *   toggle   — activate / deactivate a campaign code
 *   schedule — set start_at / ends_at on a campaign code
 *   flash    — generate a single-use code for a specific customer
 *
 * All actions talk to Shopify Admin API (price rules + discount codes)
 ***********************************************************************/

import { NextRequest, NextResponse } from 'next/server'

const SHOPIFY_STORE = process.env.SHOPIFY_STORE || 'bb0sam-tz.myshopify.com'
const SHOPIFY_TOKEN = process.env.SHOPIFY_ADMIN_API_ACCESS_TOKEN || ''

async function shopifyAdmin(endpoint: string, method = 'GET', body?: any) {
  const url = `https://${SHOPIFY_STORE}/admin/api/2024-01/${endpoint}`
  const opts: RequestInit = {
    method,
    headers: {
      'X-Shopify-Access-Token': SHOPIFY_TOKEN,
      'Content-Type': 'application/json',
    },
  }
  if (body) opts.body = JSON.stringify(body)
  const res = await fetch(url, opts)
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Shopify ${method} ${endpoint}: ${res.status} — ${text}`)
  }
  return res.json()
}

// Generate a unique flash code like "WT-FLASH-X8K2M"
function generateFlashCode(pct: number): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)]
  return `WT-${pct}OFF-${code}`
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { action, vendor_ref } = body

    if (!vendor_ref) {
      return NextResponse.json({ error: 'vendor_ref required' }, { status: 400 })
    }

    // =========================================================
    // ACTION: toggle — activate or deactivate a campaign code
    // =========================================================
    if (action === 'toggle') {
      const { price_rule_id, active } = body
      if (!price_rule_id) {
        return NextResponse.json({ error: 'price_rule_id required' }, { status: 400 })
      }

      // To "deactivate" we set ends_at to now; to "activate" we clear it
      const now = new Date().toISOString()
      const updates: any = {}

      if (active) {
        // Reactivate: set starts_at to now, clear ends_at
        updates.starts_at = now
        updates.ends_at = null
      } else {
        // Deactivate: set ends_at to now (immediately expires)
        updates.ends_at = now
      }

      const result = await shopifyAdmin(`price_rules/${price_rule_id}.json`, 'PUT', {
        price_rule: updates,
      })

      return NextResponse.json({
        success: true,
        active,
        price_rule: result.price_rule,
      })
    }

    // =========================================================
    // ACTION: schedule — set date range on a campaign code
    // =========================================================
    if (action === 'schedule') {
      const { price_rule_id, starts_at, ends_at } = body
      if (!price_rule_id) {
        return NextResponse.json({ error: 'price_rule_id required' }, { status: 400 })
      }

      const updates: any = {}
      if (starts_at) updates.starts_at = new Date(starts_at).toISOString()
      if (ends_at) updates.ends_at = new Date(ends_at).toISOString()

      // Clear schedule if both null
      if (!starts_at && !ends_at) {
        updates.starts_at = new Date().toISOString()
        updates.ends_at = null
      }

      const result = await shopifyAdmin(`price_rules/${price_rule_id}.json`, 'PUT', {
        price_rule: updates,
      })

      return NextResponse.json({
        success: true,
        starts_at: result.price_rule.starts_at,
        ends_at: result.price_rule.ends_at,
      })
    }

    // =========================================================
    // ACTION: flash — generate a one-time-use discount code
    // =========================================================
    if (action === 'flash') {
      const { percentage, expires_hours, customer_note } = body

      if (!percentage || percentage < 1 || percentage > 25) {
        return NextResponse.json({ error: 'percentage must be 1-25' }, { status: 400 })
      }

      const code = generateFlashCode(percentage)
      const expiresAt = expires_hours
        ? new Date(Date.now() + expires_hours * 60 * 60 * 1000).toISOString()
        : new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString() // default 72 hours

      // Step 1: Create a price rule for this flash code
      const priceRule = await shopifyAdmin('price_rules.json', 'POST', {
        price_rule: {
          title: `Flash ${percentage}% off — ${vendor_ref} — ${code}`,
          target_type: 'line_item',
          target_selection: 'all',
          allocation_method: 'across',
          value_type: 'percentage',
          value: `-${percentage}`,
          customer_selection: 'all',
          usage_limit: 1,              // ← ONE USE TOTAL
          once_per_customer: true,
          starts_at: new Date().toISOString(),
          ends_at: expiresAt,
        },
      })

      const priceRuleId = priceRule.price_rule.id

      // Step 2: Create the discount code on that price rule
      const discount = await shopifyAdmin(
        `price_rules/${priceRuleId}/discount_codes.json`,
        'POST',
        { discount_code: { code } }
      )

      return NextResponse.json({
        success: true,
        flash_code: code,
        percentage,
        expires_at: expiresAt,
        expires_hours: expires_hours || 72,
        usage_limit: 1,
        price_rule_id: priceRuleId,
        discount_code_id: discount.discount_code.id,
        customer_note: customer_note || null,
      })
    }

    return NextResponse.json({ error: `Unknown action: ${action}` }, { status: 400 })

  } catch (err: any) {
    console.error('Coupon manage error:', err)
    return NextResponse.json({ error: err.message || 'Internal error' }, { status: 500 })
  }
}
