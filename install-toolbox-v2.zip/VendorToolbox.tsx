'use client'

import { useState, useEffect } from 'react'

// ============================================================
// WeTwo — Vendor Toolbox v2
// Campaign codes: toggle on/off, schedule date ranges
// Flash codes: one-time use, generated on demand
// ============================================================

interface ToolboxProps {
  vendorId?: number
  vendorRef?: string
  tier?: string
}

interface FlashCode {
  code: string
  percentage: number
  expires_at: string
  customer_note?: string
  created_at: string
  used: boolean
}

// ---- Copy Button ----
function CopyBtn({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false)
  const handleCopy = async () => {
    try { await navigator.clipboard.writeText(text) } catch {
      const ta = document.createElement('textarea'); ta.value = text
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta)
    }
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button onClick={handleCopy} style={{
      padding: '5px 12px', borderRadius: '6px',
      border: copied ? '1.5px solid #22c55e' : '1.5px solid #ddd',
      background: copied ? 'rgba(34,197,94,0.08)' : '#fff',
      color: copied ? '#22c55e' : '#6b5e52',
      fontSize: '11px', fontWeight: 600, cursor: 'pointer', minWidth: '68px', fontFamily: 'inherit',
    }}>
      {copied ? '✓ Copied' : label || 'Copy'}
    </button>
  )
}

// ---- Toggle Switch ----
function Toggle({ active, onToggle, disabled }: { active: boolean; onToggle: () => void; disabled?: boolean }) {
  return (
    <button onClick={onToggle} disabled={disabled} style={{
      width: '40px', height: '22px', borderRadius: '11px',
      background: active ? '#22c55e' : '#d4cec6',
      border: 'none', cursor: disabled ? 'not-allowed' : 'pointer',
      position: 'relative' as const, transition: 'background 0.2s',
      opacity: disabled ? 0.5 : 1, flexShrink: 0,
    }}>
      <div style={{
        width: '18px', height: '18px', borderRadius: '50%', background: '#fff',
        position: 'absolute' as const, top: '2px',
        left: active ? '20px' : '2px', transition: 'left 0.2s',
        boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
      }} />
    </button>
  )
}

// ---- Schedule Picker ----
function SchedulePicker({ code, onSchedule, onClear }: {
  code: any; onSchedule: (start: string, end: string) => void; onClear: () => void
}) {
  const [open, setOpen] = useState(false)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')

  const hasSchedule = code.starts_at && code.ends_at && new Date(code.ends_at) > new Date()

  if (!open) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
        {hasSchedule ? (
          <>
            <span style={{ fontSize: '11px', color: '#3584e4', fontWeight: 600 }}>
              📅 {new Date(code.starts_at).toLocaleDateString()} — {new Date(code.ends_at).toLocaleDateString()}
            </span>
            <button onClick={onClear} style={{
              padding: '2px 8px', fontSize: '10px', border: '1px solid #e4ddd4',
              borderRadius: '4px', background: '#fff', color: '#9a8d80', cursor: 'pointer', fontFamily: 'inherit',
            }}>Clear</button>
          </>
        ) : (
          <button onClick={() => setOpen(true)} style={{
            padding: '4px 10px', fontSize: '11px', border: '1px solid #e4ddd4',
            borderRadius: '6px', background: '#fff', color: '#6b5e52', cursor: 'pointer', fontFamily: 'inherit',
            fontWeight: 600,
          }}>📅 Schedule</button>
        )}
      </div>
    )
  }

  return (
    <div style={{
      padding: '12px', background: '#fafaf8', borderRadius: '8px', border: '1px solid #e4ddd4',
      marginTop: '8px',
    }}>
      <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' as const }}>
        <label style={{ fontSize: '11px', color: '#6b5e52', fontWeight: 600 }}>Start:</label>
        <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}
          style={{ padding: '4px 8px', borderRadius: '6px', border: '1px solid #e4ddd4', fontSize: '12px', fontFamily: 'inherit' }} />
        <label style={{ fontSize: '11px', color: '#6b5e52', fontWeight: 600 }}>End:</label>
        <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
          style={{ padding: '4px 8px', borderRadius: '6px', border: '1px solid #e4ddd4', fontSize: '12px', fontFamily: 'inherit' }} />
        <button onClick={() => {
          if (startDate && endDate) {
            onSchedule(startDate, endDate)
            setOpen(false)
          }
        }} style={{
          padding: '4px 12px', fontSize: '11px', border: 'none',
          borderRadius: '6px', background: '#22c55e', color: '#fff', cursor: 'pointer', fontWeight: 700, fontFamily: 'inherit',
        }}>Set</button>
        <button onClick={() => setOpen(false)} style={{
          padding: '4px 12px', fontSize: '11px', border: '1px solid #e4ddd4',
          borderRadius: '6px', background: '#fff', color: '#9a8d80', cursor: 'pointer', fontFamily: 'inherit',
        }}>Cancel</button>
      </div>
    </div>
  )
}

// ---- Flash Code Generator ----
function FlashCodeGenerator({ vendorRef, tier }: { vendorRef: string; tier: string }) {
  const [percentage, setPercentage] = useState(10)
  const [expiresHours, setExpiresHours] = useState(72)
  const [customerNote, setCustomerNote] = useState('')
  const [generating, setGenerating] = useState(false)
  const [flashCodes, setFlashCodes] = useState<FlashCode[]>([])
  const [error, setError] = useState('')

  // Load saved flash codes from localStorage
  useEffect(() => {
    const saved = localStorage.getItem(`wetwo_flash_codes_${vendorRef}`)
    if (saved) {
      try { setFlashCodes(JSON.parse(saved)) } catch {}
    }
  }, [vendorRef])

  const saveFlashCodes = (codes: FlashCode[]) => {
    setFlashCodes(codes)
    localStorage.setItem(`wetwo_flash_codes_${vendorRef}`, JSON.stringify(codes))
  }

  const generateCode = async () => {
    setGenerating(true)
    setError('')
    try {
      const res = await fetch('/api/coupons/manage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'flash',
          vendor_ref: vendorRef,
          percentage,
          expires_hours: expiresHours,
          customer_note: customerNote || undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to generate code')

      const newCode: FlashCode = {
        code: data.flash_code,
        percentage: data.percentage,
        expires_at: data.expires_at,
        customer_note: customerNote || undefined,
        created_at: new Date().toISOString(),
        used: false,
      }
      saveFlashCodes([newCode, ...flashCodes].slice(0, 50)) // keep last 50
      setCustomerNote('')
    } catch (err: any) {
      setError(err.message)
    }
    setGenerating(false)
  }

  const expiresOptions = [
    { value: 24,  label: '24 hours' },
    { value: 48,  label: '48 hours' },
    { value: 72,  label: '3 days' },
    { value: 168, label: '7 days' },
    { value: 720, label: '30 days' },
  ]

  return (
    <div style={{ marginTop: '24px' }}>
      <div style={{
        padding: '20px', borderRadius: '14px',
        background: 'linear-gradient(135deg, rgba(229,165,10,0.06), rgba(201,148,74,0.04))',
        border: '1px solid rgba(229,165,10,0.2)',
      }}>
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '14px' }}>
          <span style={{ fontSize: '24px' }}>⚡</span>
          <div>
            <h4 style={{ margin: 0, fontSize: '15px', fontWeight: 700, color: '#2c2420' }}>Flash Code — One-Time Use</h4>
            <p style={{ margin: '2px 0 0', fontSize: '12px', color: '#9a8d80' }}>
              Generate a unique code for a specific customer. Single use, auto-expires.
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' as const, alignItems: 'flex-end', marginBottom: '12px' }}>
          {/* Percentage */}
          <div style={{ display: 'flex', flexDirection: 'column' as const, gap: '4px' }}>
            <label style={{ fontSize: '10px', color: '#9a8d80', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>Discount</label>
            <select value={percentage} onChange={e => setPercentage(+e.target.value)} style={{
              padding: '8px 12px', borderRadius: '8px', border: '1.5px solid #e4ddd4', fontSize: '14px',
              fontWeight: 700, color: '#2c2420', background: '#fff', cursor: 'pointer', fontFamily: 'inherit',
            }}>
              <option value={5}>5% off</option>
              <option value={10}>10% off</option>
              <option value={15}>15% off</option>
              <option value={20}>20% off</option>
            </select>
          </div>

          {/* Expiry */}
          <div style={{ display: 'flex', flexDirection: 'column' as const, gap: '4px' }}>
            <label style={{ fontSize: '10px', color: '#9a8d80', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>Expires in</label>
            <select value={expiresHours} onChange={e => setExpiresHours(+e.target.value)} style={{
              padding: '8px 12px', borderRadius: '8px', border: '1.5px solid #e4ddd4', fontSize: '14px',
              fontWeight: 600, color: '#2c2420', background: '#fff', cursor: 'pointer', fontFamily: 'inherit',
            }}>
              {expiresOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>

          {/* Customer note */}
          <div style={{ display: 'flex', flexDirection: 'column' as const, gap: '4px', flex: 1, minWidth: '150px' }}>
            <label style={{ fontSize: '10px', color: '#9a8d80', fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>For who? (optional)</label>
            <input
              type="text" value={customerNote}
              onChange={e => setCustomerNote(e.target.value)}
              placeholder="e.g. Sarah, bride — Feb wedding"
              style={{
                padding: '8px 12px', borderRadius: '8px', border: '1.5px solid #e4ddd4', fontSize: '13px',
                color: '#2c2420', background: '#fff', fontFamily: 'inherit',
              }}
            />
          </div>

          {/* Generate button */}
          <button onClick={generateCode} disabled={generating} style={{
            padding: '10px 20px', borderRadius: '8px', border: 'none',
            background: generating ? '#d4cec6' : 'linear-gradient(135deg, #e5a50a, #c9944a)',
            color: '#fff', fontSize: '14px', fontWeight: 700, cursor: generating ? 'wait' : 'pointer',
            whiteSpace: 'nowrap' as const, fontFamily: 'inherit',
          }}>
            {generating ? 'Generating...' : '⚡ Generate Code'}
          </button>
        </div>

        {error && <p style={{ fontSize: '12px', color: '#ef4444', margin: '8px 0 0' }}>⚠️ {error}</p>}
      </div>

      {/* Recent flash codes */}
      {flashCodes.length > 0 && (
        <div style={{ marginTop: '16px' }}>
          <h4 style={{ fontSize: '13px', fontWeight: 700, color: '#2c2420', margin: '0 0 10px' }}>
            Recent Flash Codes ({flashCodes.length})
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column' as const, gap: '6px' }}>
            {flashCodes.slice(0, 10).map((fc, i) => {
              const expired = new Date(fc.expires_at) < new Date()
              const statusColor = fc.used ? '#9a8d80' : expired ? '#ef4444' : '#22c55e'
              const statusText = fc.used ? 'Used' : expired ? 'Expired' : 'Active'
              return (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 14px',
                  borderRadius: '8px', border: '1px solid #e4ddd4', background: '#fff',
                  opacity: (fc.used || expired) ? 0.6 : 1,
                }}>
                  <div style={{
                    width: '36px', height: '36px', borderRadius: '8px',
                    background: 'rgba(229,165,10,0.08)', display: 'flex',
                    flexDirection: 'column' as const, alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>
                    <span style={{ fontSize: '13px', fontWeight: 800, color: '#e5a50a', lineHeight: 1 }}>{fc.percentage}%</span>
                    <span style={{ fontSize: '7px', color: '#9a8d80', fontWeight: 600 }}>OFF</span>
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{
                        fontFamily: "'Courier New', monospace", fontSize: '13px', fontWeight: 700, color: '#2c2420',
                      }}>{fc.code}</span>
                      <span style={{
                        fontSize: '9px', fontWeight: 700, padding: '2px 6px', borderRadius: '4px',
                        background: `${statusColor}15`, color: statusColor,
                        textTransform: 'uppercase' as const, letterSpacing: '0.04em',
                      }}>{statusText}</span>
                    </div>
                    <div style={{ fontSize: '11px', color: '#9a8d80', marginTop: '2px' }}>
                      {fc.customer_note && <span style={{ color: '#6b5e52' }}>{fc.customer_note} · </span>}
                      Expires {new Date(fc.expires_at).toLocaleDateString()} {new Date(fc.expires_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  {!fc.used && !expired && <CopyBtn text={fc.code} label="Copy" />}
                </div>
              )
            })}
          </div>
          {flashCodes.length > 10 && (
            <p style={{ fontSize: '11px', color: '#9a8d80', marginTop: '8px', textAlign: 'center' as const }}>
              Showing 10 of {flashCodes.length} flash codes
            </p>
          )}
        </div>
      )}
    </div>
  )
}

// ============================================================
// MAIN TOOLBOX COMPONENT
// ============================================================
export default function VendorToolbox({ vendorId, vendorRef, tier }: ToolboxProps) {
  const [tab, setTab] = useState('cashback')
  const [loading, setLoading] = useState<Record<string, boolean>>({})

  // Get vendor info from localStorage if not passed as props
  const [vRef, setVRef] = useState(vendorRef || '')
  const [vTier, setVTier] = useState(tier || 'free')

  useEffect(() => {
    if (!vendorRef) {
      const stored = localStorage.getItem('wetwo_vendor_session')
      if (stored) {
        const v = JSON.parse(stored)
        setVRef(v.ref || '')
        setVTier(v.boost_tier || v.plan || 'free')
      }
    }
  }, [vendorRef])

  const refSlug = vRef ? `vendor-${vRef}` : 'vendor-demo'

  // Campaign codes — these would eventually come from Supabase
  // For now, static with the toggle/schedule UI
  const [campaignCodes, setCampaignCodes] = useState([
    { pct: 5,  code: 'WTFJ3QVM', active: true,  starts_at: null as string | null, ends_at: null as string | null, price_rule_id: null as number | null },
    { pct: 10, code: 'WT28Q4QF', active: true,  starts_at: null, ends_at: null, price_rule_id: null },
    { pct: 15, code: 'WTZW4ND8', active: true,  starts_at: null, ends_at: null, price_rule_id: null },
    { pct: 20, code: 'WT7UXA9P', active: true,  starts_at: null, ends_at: null, price_rule_id: null },
  ])

  const cashbackLinks = [
    { pct: 10, locked: false, code: `https://wetwo.love/?ref=${refSlug}&cb=10` },
    { pct: 15, locked: false, code: `https://wetwo.love/?ref=${refSlug}&cb=15` },
    { pct: 20, locked: false, code: `https://wetwo.love/?ref=${refSlug}&cb=20` },
    { pct: 25, locked: vTier === 'free', code: `https://wetwo.love/?ref=${refSlug}&cb=25` },
  ]

  const handleToggle = async (index: number) => {
    const code = campaignCodes[index]
    const newActive = !code.active
    const key = `toggle-${index}`
    setLoading(prev => ({ ...prev, [key]: true }))

    if (code.price_rule_id) {
      try {
        await fetch('/api/coupons/manage', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'toggle',
            vendor_ref: vRef,
            price_rule_id: code.price_rule_id,
            active: newActive,
          }),
        })
      } catch (err) {
        console.error('Toggle error:', err)
      }
    }

    const updated = [...campaignCodes]
    updated[index] = { ...code, active: newActive }
    setCampaignCodes(updated)
    setLoading(prev => ({ ...prev, [key]: false }))
  }

  const handleSchedule = async (index: number, startDate: string, endDate: string) => {
    const code = campaignCodes[index]

    if (code.price_rule_id) {
      try {
        await fetch('/api/coupons/manage', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'schedule',
            vendor_ref: vRef,
            price_rule_id: code.price_rule_id,
            starts_at: startDate,
            ends_at: endDate,
          }),
        })
      } catch (err) {
        console.error('Schedule error:', err)
      }
    }

    const updated = [...campaignCodes]
    updated[index] = { ...code, starts_at: startDate, ends_at: endDate, active: true }
    setCampaignCodes(updated)
  }

  const handleClearSchedule = async (index: number) => {
    const code = campaignCodes[index]

    if (code.price_rule_id) {
      try {
        await fetch('/api/coupons/manage', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'schedule',
            vendor_ref: vRef,
            price_rule_id: code.price_rule_id,
            starts_at: null,
            ends_at: null,
          }),
        })
      } catch (err) {
        console.error('Clear schedule error:', err)
      }
    }

    const updated = [...campaignCodes]
    updated[index] = { ...code, starts_at: null, ends_at: null }
    setCampaignCodes(updated)
  }

  const isCashback = tab === 'cashback'

  return (
    <div>
      {/* Tab selector */}
      <div style={{ display: 'flex', marginBottom: '16px', borderRadius: '10px', overflow: 'hidden', border: '1.5px solid #e4ddd4' }}>
        <button onClick={() => setTab('cashback')} style={{
          flex: 1, padding: '10px', border: 'none',
          background: tab === 'cashback' ? '#c9944a' : '#fff',
          color: tab === 'cashback' ? '#fff' : '#6b5e52',
          fontSize: '13px', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
        }}>🎁 Registry Links (4)</button>
        <button onClick={() => setTab('coupons')} style={{
          flex: 1, padding: '10px', border: 'none', borderLeft: '1.5px solid #e4ddd4',
          background: tab === 'coupons' ? '#3b82f6' : '#fff',
          color: tab === 'coupons' ? '#fff' : '#6b5e52',
          fontSize: '13px', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
        }}>🛒 Coupon Codes (4)</button>
        <button onClick={() => setTab('flash')} style={{
          flex: 1, padding: '10px', border: 'none', borderLeft: '1.5px solid #e4ddd4',
          background: tab === 'flash' ? '#e5a50a' : '#fff',
          color: tab === 'flash' ? '#fff' : '#6b5e52',
          fontSize: '13px', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
        }}>⚡ Flash Code</button>
      </div>

      <p style={{ fontSize: '12px', color: '#9a8d80', margin: '0 0 12px', lineHeight: 1.6 }}>
        {isCashback
          ? 'Share with brides creating registries. They get cashback on every gift. You keep the rest of your pool.'
          : tab === 'coupons'
            ? 'Campaign codes — always-on or scheduled. Toggle them on/off, set date ranges for sales.'
            : 'Generate a one-time code for a specific customer. Perfect for closing deals on the spot.'}
      </p>

      {/* ===== CASHBACK LINKS ===== */}
      {tab === 'cashback' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {cashbackLinks.map((item, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 16px',
              borderRadius: '10px', border: item.locked ? '1px dashed #d4cec6' : '1px solid #e4ddd4',
              opacity: item.locked ? 0.5 : 1, background: item.locked ? '#fafaf8' : '#fff',
            }}>
              <div style={{
                width: '44px', height: '44px', borderRadius: '10px', display: 'flex',
                flexDirection: 'column' as const, alignItems: 'center', justifyContent: 'center',
                background: 'rgba(201,148,74,0.08)', flexShrink: 0,
              }}>
                <span style={{ fontSize: '16px', fontWeight: 800, color: '#c9944a', lineHeight: 1 }}>{item.pct}%</span>
                <span style={{ fontSize: '7px', fontWeight: 600, color: '#9a8d80', textTransform: 'uppercase' as const }}>back</span>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '13px', fontWeight: 600, color: '#2c2420' }}>{item.pct}% Cashback Link</div>
                {!item.locked && (
                  <div style={{
                    marginTop: '4px', padding: '3px 8px', background: '#f3efe9', borderRadius: '4px',
                    fontSize: '11px', fontFamily: "'Courier New', monospace", color: '#6b5e52',
                    display: 'inline-block', maxWidth: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const,
                  }}>{item.code}</div>
                )}
                {item.locked && <div style={{ fontSize: '12px', color: '#b0a898', marginTop: '2px' }}>Requires Starter plan</div>}
              </div>
              <div style={{ flexShrink: 0 }}>
                {item.locked
                  ? <span style={{ padding: '6px 12px', borderRadius: '6px', border: '1.5px solid #d4cec6', color: '#b0a898', fontSize: '12px', fontWeight: 600 }}>🔒 Locked</span>
                  : <CopyBtn text={item.code} label="Copy Link" />}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ===== CAMPAIGN COUPONS WITH TOGGLE + SCHEDULE ===== */}
      {tab === 'coupons' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {campaignCodes.map((code, i) => (
            <div key={i} style={{
              padding: '14px 16px', borderRadius: '10px', border: '1px solid #e4ddd4',
              background: code.active ? '#fff' : '#fafaf8',
              opacity: code.active ? 1 : 0.7,
              transition: 'all 0.2s',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                {/* Percentage badge */}
                <div style={{
                  width: '44px', height: '44px', borderRadius: '10px', display: 'flex',
                  flexDirection: 'column' as const, alignItems: 'center', justifyContent: 'center',
                  background: 'rgba(59,130,246,0.08)', flexShrink: 0,
                }}>
                  <span style={{ fontSize: '16px', fontWeight: 800, color: '#3b82f6', lineHeight: 1 }}>{code.pct}%</span>
                  <span style={{ fontSize: '7px', fontWeight: 600, color: '#9a8d80', textTransform: 'uppercase' as const }}>off</span>
                </div>

                {/* Code info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '13px', fontWeight: 600, color: '#2c2420' }}>{code.pct}% Campaign Code</span>
                    <span style={{
                      fontSize: '9px', fontWeight: 700, padding: '2px 6px', borderRadius: '4px',
                      background: code.active ? 'rgba(34,197,94,0.1)' : 'rgba(154,141,128,0.1)',
                      color: code.active ? '#22c55e' : '#9a8d80',
                      textTransform: 'uppercase' as const, letterSpacing: '0.04em',
                    }}>{code.active ? 'Active' : 'Off'}</span>
                  </div>
                  <div style={{
                    marginTop: '4px', padding: '3px 8px', background: '#f3efe9', borderRadius: '4px',
                    fontSize: '12px', fontFamily: "'Courier New', monospace", color: '#6b5e52',
                    display: 'inline-block', fontWeight: 600,
                  }}>{code.code}</div>
                </div>

                {/* Toggle */}
                <Toggle
                  active={code.active}
                  onToggle={() => handleToggle(i)}
                  disabled={!!loading[`toggle-${i}`]}
                />

                {/* Copy */}
                <CopyBtn text={code.code} label="Copy" />
              </div>

              {/* Schedule row */}
              <div style={{ marginTop: '8px', marginLeft: '56px' }}>
                <SchedulePicker
                  code={code}
                  onSchedule={(start, end) => handleSchedule(i, start, end)}
                  onClear={() => handleClearSchedule(i)}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ===== FLASH CODES ===== */}
      {tab === 'flash' && (
        <FlashCodeGenerator vendorRef={vRef} tier={vTier} />
      )}
    </div>
  )
}
