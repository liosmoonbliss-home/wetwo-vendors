'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import VendorToolbox from '@/components/VendorToolbox'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts'

// ============================================================
// WeTwo — Vendor Dashboard v2
// February 14, 2026
// Every vendor earns from day one.
// ============================================================

const TIER_INFO: Record<string, { pool: number; price: number; label: string; branded: boolean; minKeep: number; color: string }> = {
  free:    { pool: 20, price: 0,   label: 'Free',    branded: false, minKeep: 0,  color: '#6b5e52' },
  starter: { pool: 30, price: 97,  label: 'Starter', branded: true,  minKeep: 10, color: '#3584e4' },
  pro:     { pool: 35, price: 197, label: 'Pro',     branded: true,  minKeep: 15, color: '#9141ac' },
  elite:   { pool: 40, price: 297, label: 'Elite',   branded: true,  minKeep: 20, color: '#e5a50a' },
}

function generateEarningsData() {
  const data = []
  for (let sales = 0; sales <= 30; sales++) {
    data.push({
      sales,
      free: 0,
      starter: Math.max(sales * 15 - 97, -97),
      pro: Math.max(sales * 22.5 - 197, -197),
      elite: Math.max(sales * 30 - 297, -297),
    })
  }
  return data
}

const earningsData = generateEarningsData()

// ---- Copy Button ----
function CopyBtn({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false)
  const handleCopy = async () => {
    try { await navigator.clipboard.writeText(text) } catch {
      const ta = document.createElement('textarea'); ta.value = text
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta)
    }
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button onClick={handleCopy} style={{
      padding: '6px 14px', borderRadius: '6px',
      border: copied ? '1.5px solid #22c55e' : '1.5px solid #ddd',
      background: copied ? 'rgba(34,197,94,0.08)' : '#fff',
      color: copied ? '#22c55e' : '#6b5e52',
      fontSize: '12px', fontWeight: 600, cursor: 'pointer', minWidth: '76px', fontFamily: 'inherit',
    }}>
      {copied ? '✓ Copied' : label || 'Copy'}
    </button>
  )
}

// ---- Pool Math Visual ----
function PoolMath({ tier }: { tier: string }) {
  const t = TIER_INFO[tier] || TIER_INFO.free
  const sale = 150
  const pool = sale * (t.pool / 100)
  const scenarios = [
    { give: 0, keepPct: t.pool },
    { give: 5, keepPct: t.pool - 5 },
    { give: 10, keepPct: t.pool - 10 },
    { give: 15, keepPct: t.pool - 15 },
    { give: 20, keepPct: t.pool - 20 },
  ]

  return (
    <div style={{ background: '#fff', borderRadius: '14px', border: '1px solid #e4ddd4', padding: '24px', marginBottom: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <div>
          <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700, color: '#2c2420' }}>Your Pool Math</h3>
          <p style={{ margin: '4px 0 0', fontSize: '13px', color: '#6b5e52' }}>
            On every $150 gift, your {t.pool}% pool = <strong style={{ color: '#22c55e' }}>${pool.toFixed(0)}</strong>
          </p>
        </div>
        <span style={{
          padding: '4px 12px', borderRadius: '20px', fontSize: '11px', fontWeight: 700,
          textTransform: 'uppercase' as const, letterSpacing: '0.06em',
          background: tier === 'free' ? '#f5f5f3' : `${t.color}15`, color: t.color,
        }}>
          {t.label}{t.price > 0 ? ` — $${t.price}/mo` : ''}
        </span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '6px' }}>
        {scenarios.map(s => (
          <div key={s.give} style={{
            background: s.give === 0 ? 'linear-gradient(135deg, rgba(34,197,94,0.06), rgba(34,197,94,0.02))' : '#fafaf8',
            borderRadius: '10px', padding: '12px 8px', textAlign: 'center' as const,
            border: s.give === 0 ? '1px solid rgba(34,197,94,0.2)' : '1px solid #e4ddd4',
          }}>
            <div style={{ fontSize: '10px', color: '#9a8d80', fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: '4px' }}>
              {s.give === 0 ? 'Keep all' : `Give ${s.give}%`}
            </div>
            <div style={{ fontSize: '18px', fontWeight: 700, color: s.keepPct > 0 ? '#22c55e' : '#ccc' }}>
              ${(sale * s.keepPct / 100).toFixed(0)}
            </div>
            <div style={{ fontSize: '9px', color: '#9a8d80', marginTop: '2px' }}>you keep</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ---- Incentive Tools ----
function IncentiveTools({ tier, vendorRef }: { tier: string; vendorRef: string }) {
  const [tab, setTab] = useState('cashback')

  const refSlug = vendorRef ? `vendor-${vendorRef}` : 'vendor-demo'
  const cashbackLinks = [
    { pct: 10, locked: false, code: `https://wetwo.love/?ref=${refSlug}&cb=10` },
    { pct: 15, locked: false, code: `https://wetwo.love/?ref=${refSlug}&cb=15` },
    { pct: 20, locked: false, code: `https://wetwo.love/?ref=${refSlug}&cb=20` },
    { pct: 25, locked: tier === 'free', code: `https://wetwo.love/?ref=${refSlug}&cb=25` },
  ]
  const couponCodes = [
    { pct: 5,  locked: false, code: '——' },
    { pct: 10, locked: false, code: '——' },
    { pct: 15, locked: false, code: '——' },
    { pct: 20, locked: false, code: '——' },
  ]

  const items = tab === 'cashback' ? cashbackLinks : couponCodes
  const isCashback = tab === 'cashback'

  return (
    <div style={{ background: '#fff', borderRadius: '14px', border: '1px solid #e4ddd4', padding: '24px', marginBottom: '20px' }}>
      <h3 style={{ margin: '0 0 4px', fontSize: '16px', fontWeight: 700, color: '#2c2420' }}>Your 8 Tools</h3>
      <p style={{ margin: '0 0 16px', fontSize: '13px', color: '#6b5e52' }}>
        Cashback links for brides. Discount codes for everyone. Use them to build lists, reward loyalty, run campaigns.
      </p>
      <div style={{ display: 'flex', marginBottom: '16px', borderRadius: '10px', overflow: 'hidden', border: '1.5px solid #e4ddd4' }}>
        <button onClick={() => setTab('cashback')} style={{
          flex: 1, padding: '10px', border: 'none',
          background: tab === 'cashback' ? '#c9944a' : '#fff',
          color: tab === 'cashback' ? '#fff' : '#6b5e52',
          fontSize: '13px', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
        }}>🎁 Registry Links (4)</button>
        <button onClick={() => setTab('coupons')} style={{
          flex: 1, padding: '10px', border: 'none', borderLeft: '1.5px solid #e4ddd4',
          background: tab === 'coupons' ? '#3b82f6' : '#fff',
          color: tab === 'coupons' ? '#fff' : '#6b5e52',
          fontSize: '13px', fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit',
        }}>🛒 Coupon Codes (4)</button>
      </div>
      <p style={{ fontSize: '12px', color: '#9a8d80', margin: '0 0 12px', lineHeight: 1.6 }}>
        {isCashback
          ? 'Share with brides creating registries. They get cashback on every gift. You keep the rest of your pool.'
          : 'Share on social, your website, or with clients. Instant discount at checkout. Perfect for loyalty rewards and reactivation.'}
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {items.map((item, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 16px',
            borderRadius: '10px', border: item.locked ? '1px dashed #d4cec6' : '1px solid #e4ddd4',
            opacity: item.locked ? 0.5 : 1, background: item.locked ? '#fafaf8' : '#fff',
          }}>
            <div style={{
              width: '44px', height: '44px', borderRadius: '10px', display: 'flex',
              flexDirection: 'column' as const, alignItems: 'center', justifyContent: 'center',
              background: isCashback ? 'rgba(201,148,74,0.08)' : 'rgba(59,130,246,0.08)', flexShrink: 0,
            }}>
              <span style={{ fontSize: '16px', fontWeight: 800, color: isCashback ? '#c9944a' : '#3b82f6', lineHeight: 1 }}>{item.pct}%</span>
              <span style={{ fontSize: '7px', fontWeight: 600, color: '#9a8d80', textTransform: 'uppercase' as const }}>{isCashback ? 'back' : 'off'}</span>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: '13px', fontWeight: 600, color: '#2c2420' }}>
                {isCashback ? `${item.pct}% Cashback Link` : `${item.pct}% Discount Code`}
              </div>
              {!item.locked && (
                <div style={{
                  marginTop: '4px', padding: '3px 8px', background: '#f3efe9', borderRadius: '4px',
                  fontSize: '11px', fontFamily: "'Courier New', monospace", color: '#6b5e52',
                  display: 'inline-block', maxWidth: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const,
                }}>{item.code}</div>
              )}
              {item.locked && <div style={{ fontSize: '12px', color: '#b0a898', marginTop: '2px' }}>Requires Starter plan</div>}
            </div>
            <div style={{ flexShrink: 0 }}>
              {item.locked
                ? <span style={{ padding: '6px 12px', borderRadius: '6px', border: '1.5px solid #d4cec6', color: '#b0a898', fontSize: '12px', fontWeight: 600 }}>🔒 Locked</span>
                : <CopyBtn text={item.code} label={isCashback ? 'Copy Link' : 'Copy Code'} />}
            </div>
          </div>
        ))}
      </div>

      {/* Full toolbox from Supabase (when vendor has generated incentives) */}
      <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid #e4ddd4' }}>
        <p style={{ fontSize: '12px', color: '#9a8d80', margin: '0 0 12px' }}>
          📊 Detailed view with real-time stats and earnings:
        </p>
        <VendorToolbox vendorId={undefined} />
      </div>
    </div>
  )
}

// ---- Earnings Growth Chart ----
function EarningsChart() {
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload) return null
    return (
      <div style={{
        background: '#2c2420', borderRadius: '10px', padding: '14px 18px',
        boxShadow: '0 8px 24px rgba(0,0,0,0.2)', border: 'none',
      }}>
        <p style={{ margin: '0 0 8px', fontSize: '13px', fontWeight: 700, color: '#fff' }}>
          {label} sales/mo × $150
        </p>
        {payload.filter((p: any) => p.dataKey !== 'free').map((p: any, i: number) => (
          <p key={i} style={{ margin: '2px 0', fontSize: '12px', color: p.color }}>
            <span style={{ fontWeight: 700 }}>{p.name}:</span>{' '}
            <span style={{ fontWeight: 800 }}>${p.value.toFixed(0)}</span>
            {p.value > 0 ? '/mo profit' : ''}
          </p>
        ))}
      </div>
    )
  }

  return (
    <div style={{ background: '#fff', borderRadius: '14px', border: '1px solid #e4ddd4', padding: '28px', marginBottom: '20px' }}>
      <div style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', gap: '14px', alignItems: 'center', marginBottom: '8px' }}>
          <span style={{ fontSize: '28px' }}>📈</span>
          <h2 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: '19px', color: '#2c2420', margin: 0 }}>
            After break-even, higher tiers take off
          </h2>
        </div>
        <p style={{ fontSize: '14px', color: '#6b5e52', lineHeight: 1.6, margin: 0 }}>
          Break-even is within 7–10 sales for every tier — basically the same. But look what happens after:
          Elite earns at <strong style={{ color: '#2c2420' }}>double the rate</strong> of Starter.
          If you can't make 10 sales a month, close your doors. This should be a no-brainer.
        </p>
      </div>

      <ResponsiveContainer width="100%" height={320}>
        <LineChart data={earningsData} margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0ece6" />
          <XAxis dataKey="sales" tick={{ fontSize: 11, fill: '#9a8d80' }}
            label={{ value: 'Sales per month', position: 'insideBottom', offset: -2, fontSize: 12, fill: '#9a8d80' }} />
          <YAxis tick={{ fontSize: 11, fill: '#9a8d80' }} tickFormatter={(v: number) => `$${v}`}
            label={{ value: 'Monthly profit', angle: -90, position: 'insideLeft', offset: 10, fontSize: 12, fill: '#9a8d80' }} />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine y={0} stroke="#e4ddd4" strokeWidth={2} />
          <ReferenceLine x={7} stroke="#3584e4" strokeDasharray="4 4" strokeOpacity={0.4} />
          <ReferenceLine x={10} stroke="#e5a50a" strokeDasharray="4 4" strokeOpacity={0.4} />
          <Line type="monotone" dataKey="starter" name="Starter $97/mo" stroke="#3584e4" strokeWidth={2.5} dot={false} activeDot={{ r: 5, fill: '#3584e4' }} />
          <Line type="monotone" dataKey="pro" name="Pro $197/mo" stroke="#9141ac" strokeWidth={2.5} dot={false} activeDot={{ r: 5, fill: '#9141ac' }} />
          <Line type="monotone" dataKey="elite" name="Elite $297/mo" stroke="#e5a50a" strokeWidth={3} dot={false} activeDot={{ r: 6, fill: '#e5a50a' }} />
          <Legend verticalAlign="top" height={36}
            formatter={(value: string) => <span style={{ fontSize: '12px', color: '#6b5e52', fontWeight: 600 }}>{value}</span>} />
        </LineChart>
      </ResponsiveContainer>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', marginTop: '20px' }}>
        {[
          { tier: 'Starter', profit: 20 * 15 - 97, rate: '$15', color: '#3584e4' },
          { tier: 'Pro', profit: 20 * 22.5 - 197, rate: '$22.50', color: '#9141ac' },
          { tier: 'Elite', profit: 20 * 30 - 297, rate: '$30', color: '#e5a50a' },
        ].map(p => (
          <div key={p.tier} style={{
            textAlign: 'center' as const, padding: '16px', borderRadius: '12px',
            background: `${p.color}08`, border: `1px solid ${p.color}25`,
          }}>
            <div style={{ fontSize: '11px', color: '#9a8d80', fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: '4px' }}>
              {p.tier} at 20 sales
            </div>
            <div style={{ fontSize: '24px', fontWeight: 800, color: p.color }}>${p.profit.toFixed(0)}</div>
            <div style={{ fontSize: '11px', color: '#6b5e52', marginTop: '2px' }}>{p.rate}/sale after break-even</div>
          </div>
        ))}
      </div>

      <div style={{
        marginTop: '20px', padding: '16px 20px', borderRadius: '12px',
        background: 'rgba(229,165,10,0.08)', border: '1px solid rgba(229,165,10,0.2)', textAlign: 'center' as const,
      }}>
        <p style={{ margin: 0, fontSize: '15px', color: '#2c2420', fontWeight: 600, fontFamily: "'Playfair Display', Georgia, serif" }}>
          One wedding registry. 150 guests. At Elite giving the full 20%:<br/>
          <span style={{ fontSize: '24px', color: '#22c55e' }}>$4,500 profit</span>
          <span style={{ fontSize: '14px', color: '#9a8d80' }}> — from one couple.</span>
        </p>
      </div>
    </div>
  )
}

// ---- Upgrade Card ----
function UpgradeCard({ currentTier }: { currentTier: string }) {
  if (currentTier !== 'free') return null
  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(34,197,94,0.05), rgba(201,148,74,0.05))',
      borderRadius: '14px', border: '1px solid rgba(34,197,94,0.2)', padding: '28px', marginBottom: '20px',
    }}>
      <div style={{ fontSize: '11px', fontWeight: 800, color: '#22c55e', textTransform: 'uppercase' as const, letterSpacing: '0.08em', marginBottom: '10px' }}>
        KEEP MORE. GIVE MORE. GROW MORE.
      </div>
      <h3 style={{ margin: '0 0 12px', fontSize: '20px', fontWeight: 700, color: '#2c2420', fontFamily: "'Playfair Display', Georgia, serif", lineHeight: 1.3 }}>
        Upgrade and give the full 20% — while still earning on every sale.
      </h3>
      <p style={{ fontSize: '14px', color: '#6b5e52', lineHeight: 1.7, margin: '0 0 20px' }}>
        Right now you can keep up to 20% or give it all away. Upgrade to Starter and your pool grows to 30% —
        so even giving the maximum 20% to customers, you still keep 10% on every sale. Plus you get your own branded store,
        no WeTwo branding, and the ability to add your own products and services.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px', marginBottom: '20px' }}>
        {[
          { name: 'Starter', price: 97, pool: 30, keep: 10, breakEven: '7 gifts', daily: '3.23', color: '#3584e4' },
          { name: 'Pro',     price: 197, pool: 35, keep: 15, breakEven: '9 gifts', daily: '6.57', color: '#9141ac' },
          { name: 'Elite',   price: 297, pool: 40, keep: 20, breakEven: '10 gifts', daily: '9.90', color: '#e5a50a', featured: true },
        ].map((plan: any) => (
          <div key={plan.name} style={{
            background: '#fff', borderRadius: '12px', padding: '20px 16px', textAlign: 'center' as const,
            border: plan.featured ? `2px solid ${plan.color}` : '1px solid #e4ddd4',
            position: 'relative' as const,
          }}>
            {plan.featured && (
              <div style={{
                position: 'absolute' as const, top: '-10px', left: '50%', transform: 'translateX(-50%)',
                background: plan.color, color: '#fff', fontSize: '10px', fontWeight: 700,
                padding: '2px 12px', borderRadius: '10px', whiteSpace: 'nowrap' as const,
              }}>Best Value</div>
            )}
            <div style={{ fontSize: '16px', fontWeight: 700, color: '#2c2420', marginBottom: '2px' }}>{plan.name}</div>
            <div style={{ fontSize: '24px', fontWeight: 800, color: plan.color }}>${plan.price}<span style={{ fontSize: '13px', fontWeight: 400, color: '#9a8d80' }}>/mo</span></div>
            <div style={{ fontSize: '11px', color: '#c9944a', fontWeight: 600, fontStyle: 'italic', marginBottom: '12px' }}>${plan.daily}/day</div>
            <div style={{ fontSize: '13px', color: '#6b5e52', marginBottom: '4px' }}>{plan.pool}% pool</div>
            <div style={{ fontSize: '14px', fontWeight: 700, color: '#22c55e', marginBottom: '4px' }}>Always keep {plan.keep}%</div>
            <div style={{ fontSize: '12px', color: '#6b5e52' }}>even giving max 20%</div>
            <div style={{
              marginTop: '12px', padding: '8px', background: 'rgba(34,197,94,0.06)', borderRadius: '8px',
              fontSize: '12px', color: '#2c2420',
            }}>
              Break even: <strong style={{ color: '#22c55e' }}>{plan.breakEven}</strong>
              <div style={{ fontSize: '11px', color: '#9a8d80', marginTop: '2px' }}>at $150 avg gift</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ background: '#fff', borderRadius: '12px', border: '1px solid #e4ddd4', padding: '20px', marginBottom: '16px' }}>
        <h4 style={{ margin: '0 0 8px', fontSize: '14px', fontWeight: 700, color: '#2c2420' }}>Paid tier benefits</h4>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
          {[
            'Your branding throughout — no WeTwo',
            'Bigger pool = earn more on every sale',
            'Add your own products & services to the store',
            'Your incentives apply to everything in store',
            '25% cashback link unlocked',
            'Give the full 20% and still profit',
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', gap: '8px', alignItems: 'flex-start', fontSize: '13px', color: '#6b5e52' }}>
              <span style={{ color: '#22c55e', fontWeight: 700, flexShrink: 0 }}>✓</span>
              {item}
            </div>
          ))}
        </div>
      </div>
      <div style={{ textAlign: 'center' as const }}>
        <Link href="/dashboard/earnings" style={{
          display: 'inline-block', padding: '14px 32px', background: '#22c55e', color: '#fff',
          borderRadius: '10px', fontSize: '15px', fontWeight: 700, textDecoration: 'none',
        }}>Upgrade Now →</Link>
      </div>
    </div>
  )
}

// ============================================================
// MAIN DASHBOARD PAGE
// ============================================================
export default function DashboardHome() {
  const [vendor, setVendor] = useState<any>(null)
  const [stats, setStats] = useState({ leads: 0, couples: 0, shoppers: 0, totalCommission: 0 })
  const [activeTab, setActiveTab] = useState('dashboard')

  useEffect(() => {
    const stored = localStorage.getItem('wetwo_vendor_session')
    if (stored) {
      const v = JSON.parse(stored)
      setVendor(v)
      fetch(`/api/dashboard/stats?ref=${v.ref}`)
        .then(r => r.json())
        .then(d => { if (d.stats) setStats(d.stats) })
        .catch(() => {})
    }
  }, [])

  if (!vendor) return null

  const firstName = (vendor.contact_name || vendor.business_name || '').split(' ')[0]
  const tier = vendor.boost_tier || vendor.plan || 'free'
  const t = TIER_INFO[tier] || TIER_INFO.free
  const pageLink = `https://wetwo-vendors.vercel.app/vendor/${vendor.ref}`

  const tabs = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'howto', label: 'How to Use' },
    { id: 'upgrade', label: 'Grow Your Business', highlight: true },
    { id: 'playbook', label: 'Playbook' },
  ]

  return (
    <div>
      {/* ===== HEADER ===== */}
      <header className="page-header">
        <div>
          <h1 className="page-title">Welcome, {firstName} 👋</h1>
          <p className="page-subtitle">You're earning on every sale. Let's grow.</p>
        </div>
        <Link href={`/vendor/${vendor.ref}`} target="_blank" className="header-btn">
          View Your Page →
        </Link>
      </header>

      <div className="page-content">

        {/* ===== HERO EARNINGS BANNER ===== */}
        <div className="hero-earnings-banner">
          <div className="hero-earnings-inner">
            <div className="hero-earnings-text">
              <div className="hero-earnings-badge">YOU'RE IN BUSINESS</div>
              <h2 className="hero-earnings-headline">
                You earn {t.pool}% on every product sold through your store.
              </h2>
              <p className="hero-earnings-desc">
                Every product is priced at or below market — we don't make margin, we make memberships.
                Like Costco for small businesses. Your {t.pool}% pool is yours to keep or share as incentives.
              </p>
            </div>
            <div className="hero-earnings-stats">
              <div className="hero-stat-box">
                <div className="hero-stat-value green">${stats.totalCommission > 0 ? stats.totalCommission.toFixed(0) : '0'}</div>
                <div className="hero-stat-label">Total Earned</div>
              </div>
              <div className="hero-stat-box">
                <div className="hero-stat-value gold">{stats.couples + stats.shoppers}</div>
                <div className="hero-stat-label">Sales</div>
              </div>
            </div>
          </div>
        </div>

        {/* ===== QUICK ACTIONS ===== */}
        <div className="toolkit-grid">
          <a href={pageLink} target="_blank" rel="noopener" className="tool-card">
            <div className="tool-icon-wrap" style={{ background: 'rgba(201,148,74,0.08)' }}><span style={{ fontSize: '22px' }}>🏪</span></div>
            <div className="tool-label">Your Store</div>
            <div className="tool-status" style={{ color: '#c9944a' }}>Live →</div>
          </a>
          <a href="#tools" onClick={(e) => { e.preventDefault(); setActiveTab('dashboard'); }} className="tool-card">
            <div className="tool-icon-wrap" style={{ background: 'rgba(34,197,94,0.08)' }}><span style={{ fontSize: '22px' }}>🔗</span></div>
            <div className="tool-label">Your Tools</div>
            <div className="tool-status" style={{ color: '#22c55e' }}>8 Ready ↓</div>
          </a>
          <Link href="/dashboard/assistant" className="tool-card">
            <div className="tool-icon-wrap" style={{ background: 'rgba(124,107,196,0.08)' }}><span style={{ fontSize: '22px' }}>✨</span></div>
            <div className="tool-label">AI Assistant</div>
            <div className="tool-status" style={{ color: '#7c6bc4' }}>Ask Claude →</div>
          </Link>
          <Link href="/dashboard/clients" className="tool-card">
            <div className="tool-icon-wrap" style={{ background: 'rgba(59,130,246,0.08)' }}><span style={{ fontSize: '22px' }}>👥</span></div>
            <div className="tool-label">Contacts</div>
            <div className="tool-status" style={{ color: '#3b82f6' }}>Manage →</div>
          </Link>
        </div>

        {/* ===== TABS ===== */}
        <div className="tabs-bar">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`tab-btn ${activeTab === tab.id ? 'active' : ''} ${(tab as any).highlight ? 'tab-highlight' : ''}`}
            >{tab.label}{(tab as any).highlight && activeTab !== tab.id ? ' 🚀' : ''}</button>
          ))}
        </div>

        {/* ===== TAB: DASHBOARD ===== */}
        {activeTab === 'dashboard' && (
          <div className="tab-content">
            <PoolMath tier={tier} />
            <IncentiveTools tier={tier} vendorRef={vendor.ref} />
            <UpgradeCard currentTier={tier} />
          </div>
        )}

        {/* ===== TAB: HOW TO USE ===== */}
        {activeTab === 'howto' && (
          <div className="tab-content">
            <div className="content-card">
              <div className="card-header-row">
                <span className="card-icon">💡</span>
                <h2>How the model works</h2>
              </div>
              <p>Every product in your store is verified at market price — most are better than market, because our model isn't to make margin. It's to pass it to you and your clients. We're like <strong>Costco for small businesses</strong> — we make our money on memberships, not markups.</p>
              <p>You earn <strong style={{ color: '#22c55e' }}>{t.pool}% on everything sold</strong> through your store — immediately. No approval needed, no waiting period. That pool is yours to keep entirely, or share as incentives (cashback for brides, discount codes for shoppers) up to 20%.</p>
              <p style={{ marginBottom: 0 }}>The more you give, the more people use your links. The more they use your links, the more you sell. Generosity isn't just the right thing — it's the math.</p>
            </div>

            <div className="content-card">
              <div className="card-header-row">
                <span className="card-icon">🎯</span>
                <h2>What to do with your 8 tools</h2>
              </div>
              {[
                { icon: '🔄', title: 'Run a reactivation campaign', desc: "Text every cold lead: 'I just got access to something I want to share with you — exclusive cashback on thousands of products. Can I send you the details?' You're not selling. You're giving." },
                { icon: '🤝', title: 'Build a loyalty program', desc: 'Give your best clients a coupon code. 5% off for everyone, 10% for repeat clients, 15% for referrals. Real rewards backed by real discounts — not a punch card.' },
                { icon: '✈️', title: 'Fund honeymoons', desc: 'Give brides your cashback link. 150 guests × $150 avg gift = the couple could get thousands back in cash. Every guest sees your name on the gift. Hundreds of impressions per wedding.' },
                { icon: '📱', title: 'Grow your following', desc: "'DM me GIFT for exclusive savings on thousands of products.' Every DM is a warm lead who came to you. Use your codes to reward engagement and capture contact info." },
                { icon: '📧', title: 'Add to everything', desc: 'Email signature, business cards, website, Instagram bio. One link. Your store is always open, always earning, always growing your list.' },
              ].map((item, i) => (
                <div key={i} style={{ display: 'flex', gap: '14px', padding: '16px 0', borderBottom: i < 4 ? '1px solid #f0ece6' : 'none' }}>
                  <span style={{ fontSize: '22px', flexShrink: 0, marginTop: '2px' }}>{item.icon}</span>
                  <div>
                    <h4 style={{ margin: '0 0 4px', fontSize: '15px', fontWeight: 700, color: '#2c2420' }}>{item.title}</h4>
                    <p style={{ margin: 0, fontSize: '14px', color: '#6b5e52', lineHeight: 1.6 }}>{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="content-card claude-card">
              <div className="claude-header-row">
                <span className="claude-sparkle">✨</span>
                <div>
                  <h3>Need help? Claude knows everything.</h3>
                  <p>Write outreach messages, reactivation campaigns, Instagram captions — Claude is your marketing assistant.</p>
                </div>
              </div>
              <Link href="/dashboard/assistant" className="claude-btn">Talk to Claude →</Link>
            </div>
          </div>
        )}

        {/* ===== TAB: GROW YOUR BUSINESS ===== */}
        {activeTab === 'upgrade' && (
          <div className="tab-content">
            <EarningsChart />
            <UpgradeCard currentTier={tier} />

            <div className="content-card">
              <div className="card-header-row">
                <span className="card-icon">📐</span>
                <h2>The math at maximum generosity</h2>
              </div>
              <p>At an average wedding gift of $150, giving the <strong>full 20% incentive</strong> — the most generous offer you can make:</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {[
                  { tier: 'Free', keep: 0, gifts: '—', after: 'You give everything. Pure generosity. Build your list and reputation.', color: '#6b5e52' },
                  { tier: 'Starter $97/mo', keep: 10, gifts: '~7', after: "After 7 gifts you've covered the $97. Every sale after = pure profit at $15/gift.", color: '#3584e4' },
                  { tier: 'Pro $197/mo', keep: 15, gifts: '~9', after: "After 9 gifts you've covered the $197. Profit at $22.50/gift — 50% more than Starter.", color: '#9141ac' },
                  { tier: 'Elite $297/mo', keep: 20, gifts: '~10', after: "After 10 gifts you've covered the $297. Profit grows at $30/gift — double the Starter rate.", color: '#e5a50a' },
                ].map((row, i) => (
                  <div key={i} style={{
                    padding: '16px 20px', borderRadius: '12px',
                    border: `1px solid ${row.color}30`, background: `${row.color}08`,
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                      <span style={{ fontSize: '15px', fontWeight: 700, color: '#2c2420' }}>{row.tier}</span>
                      <span style={{ fontSize: '14px', fontWeight: 700, color: '#22c55e' }}>
                        {row.keep > 0 ? `Keep ${row.keep}% = $${(150 * row.keep / 100).toFixed(0)}/gift` : 'Keep $0'}
                      </span>
                    </div>
                    <div style={{ fontSize: '13px', color: '#6b5e52' }}>
                      {row.gifts !== '—' && <><strong>Break even:</strong> {row.gifts} gifts at $150. </>}
                      {row.after}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="content-card">
              <div className="card-header-row">
                <span className="card-icon">🏷️</span>
                <h2>Add your own products and services</h2>
              </div>
              <p>On any paid tier, you get a featured collection spot right at the top of your store — before the WeTwo catalog. Add your own products, services, packages, or gift cards. Your incentive codes apply to everything in the store, including your custom items.</p>
              <p style={{ marginBottom: 0, color: '#9a8d80', fontSize: '14px' }}>A DJ could add booking packages. A florist could add arrangement consultations. A photographer could sell prints. It's your store — customize it to match your business.</p>
            </div>
          </div>
        )}

        {/* ===== TAB: PLAYBOOK ===== */}
        {activeTab === 'playbook' && (
          <div className="tab-content">
            <div style={{ marginBottom: '20px' }}>
              <h2 style={{ fontFamily: "'Playfair Display', Georgia, serif", fontSize: '22px', fontWeight: 700, color: '#2c2420', margin: '0 0 4px' }}>Your First Week</h2>
              <p style={{ fontSize: '14px', color: '#6b5e52', margin: 0 }}>You're earning from day one. Here's how to make the most of it.</p>
            </div>
            <div className="playbook">
              {[
                { num: '1', title: 'Shop your own store first', desc: "Buy something. Feel the savings. See how the experience works from the customer side. You can't sell what you haven't experienced." },
                { num: '2', title: 'Text 5 past clients', desc: "'I just got access to something I want to share with you — exclusive savings on thousands of products. Can I send you the link?' Gauge interest. Get yes replies flowing.", hint: 'Have Claude write the message →', hintLink: '/dashboard/assistant' },
                { num: '3', title: 'Send your best code', desc: 'Give your most engaged contacts a 10% or 15% discount code. Real savings, instant value. Watch the orders come in — and watch your pool grow.' },
                { num: '4', title: 'Post on Instagram', desc: "'I have a gift for you 🎁 DM me GIFT for exclusive access to savings on thousands of products.' Every DM is a warm lead who came to you.", hint: 'Have Claude write the caption →', hintLink: '/dashboard/assistant' },
                { num: '5', title: "Set up a couple's registry", desc: 'Give one bride your cashback link. 150 guests, $150 avg gift = thousands in cashback for the couple, hundreds of people seeing your name. One registry changes everything.' },
                { num: '⚡', title: 'Upgrade when you\'re ready to scale', desc: "You're already earning. Upgrade to get your brand on the store, add your own products, and keep more on every sale — even while giving the maximum 20% to customers.", highlight: true },
              ].map((step: any, i) => (
                <div key={i} className={`play ${step.highlight ? 'highlight' : ''}`}>
                  <div className={`play-number ${step.highlight ? 'upgrade' : ''}`}>{step.num}</div>
                  <div className="play-content">
                    <h4>{step.title}</h4>
                    <p>{step.desc}</p>
                    {step.hint && <Link href={step.hintLink || '#'} className="play-link">{step.hint}</Link>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      <style jsx>{`
        .page-header { background: #fff; border-bottom: 1px solid #e4ddd4; padding: 20px 32px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 50; }
        .page-title { font-size: 20px; font-weight: 700; color: #2c2420; margin: 0; }
        .page-subtitle { font-size: 13px; color: #c9944a; margin: 2px 0 0; font-weight: 600; }
        .header-btn { padding: 8px 16px; background: transparent; border: 1px solid #e4ddd4; border-radius: 8px; color: #6b5e52; text-decoration: none; font-size: 13px; font-weight: 600; transition: all 0.2s; }
        .header-btn:hover { border-color: #c9944a; color: #c9944a; }
        .page-content { padding: 28px 32px; max-width: 880px; }

        .hero-earnings-banner { background: linear-gradient(135deg, #2c2420, #1a1614); border-radius: 16px; padding: 28px 32px; margin-bottom: 24px; color: #fff; }
        .hero-earnings-inner { display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 20px; }
        .hero-earnings-text { flex: 1; min-width: 280px; }
        .hero-earnings-badge { font-size: 11px; font-weight: 800; color: #c9944a; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 8px; }
        .hero-earnings-headline { font-family: 'Playfair Display', Georgia, serif; font-size: 24px; font-weight: 600; margin: 0 0 10px; line-height: 1.3; color: #fff; }
        .hero-earnings-desc { font-size: 14px; color: rgba(255,255,255,0.65); line-height: 1.6; margin: 0; }
        .hero-earnings-stats { display: flex; gap: 16px; flex-shrink: 0; }
        .hero-stat-box { text-align: center; padding: 16px 20px; background: rgba(255,255,255,0.06); border-radius: 12px; border: 1px solid rgba(255,255,255,0.1); }
        .hero-stat-value { font-size: 28px; font-weight: 800; }
        .hero-stat-value.green { color: #22c55e; }
        .hero-stat-value.gold { color: #c9944a; }
        .hero-stat-label { font-size: 11px; color: rgba(255,255,255,0.5); text-transform: uppercase; letter-spacing: 0.04em; margin-top: 4px; }

        .toolkit-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px; }
        .tool-card { background: #fff; border: 1px solid #e4ddd4; border-radius: 14px; padding: 20px 16px; text-align: center; cursor: pointer; text-decoration: none; color: inherit; transition: all 0.2s ease; display: flex; flex-direction: column; align-items: center; gap: 8px; }
        .tool-card:hover { border-color: #c9944a; box-shadow: 0 4px 16px rgba(201,148,74,0.1); transform: translateY(-2px); }
        .tool-icon-wrap { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; }
        .tool-label { font-size: 13px; font-weight: 700; color: #2c2420; }
        .tool-status { font-size: 12px; font-weight: 600; }

        .tabs-bar { display: flex; gap: 4px; margin-bottom: 24px; border-bottom: 1px solid #e4ddd4; padding-bottom: 0; }
        .tab-btn { padding: 10px 20px; background: none; border: none; border-bottom: 2px solid transparent; font-size: 14px; font-weight: 600; color: #9a8d80; cursor: pointer; transition: all 0.2s; font-family: inherit; }
        .tab-btn:hover { color: #6b5e52; }
        .tab-btn.active { color: #c9944a; border-bottom-color: #c9944a; }
        .tab-btn.tab-highlight { background: rgba(34,197,94,0.08); border-radius: 8px 8px 0 0; font-weight: 800; color: #22c55e; letter-spacing: 0.02em; }
        .tab-btn.tab-highlight.active { background: linear-gradient(135deg, #22c55e, #1aab4d); color: #fff; border-bottom: 2px solid transparent; }
        .tab-btn.tab-highlight:hover { color: #1a9a42; }
        .tab-btn.tab-highlight.active:hover { color: #fff; }
        .tab-content { animation: fadeIn 0.2s ease; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }

        .content-card { background: #fff; border: 1px solid #e4ddd4; border-radius: 16px; padding: 28px; margin-bottom: 16px; }
        .content-card p { font-size: 15px; color: #6b5e52; line-height: 1.7; margin: 0 0 12px; }
        .content-card p strong { color: #2c2420; }
        .card-header-row { display: flex; gap: 14px; align-items: center; margin-bottom: 16px; }
        .card-icon { font-size: 28px; flex-shrink: 0; }
        .card-header-row h2 { font-family: 'Playfair Display', Georgia, serif; font-size: 19px; color: #2c2420; margin: 0; line-height: 1.3; }

        .claude-card { background: linear-gradient(135deg, rgba(124,107,196,0.08), rgba(201,148,74,0.06)); border-color: rgba(124,107,196,0.25); }
        .claude-header-row { display: flex; gap: 16px; align-items: flex-start; margin-bottom: 16px; }
        .claude-sparkle { font-size: 32px; flex-shrink: 0; }
        .claude-card h3 { font-size: 17px; font-weight: 700; color: #2c2420; margin: 0 0 6px; line-height: 1.3; }
        .claude-card > .claude-header-row p { font-size: 14px; color: #6b5e52; margin: 0; line-height: 1.6; }
        .claude-btn { display: inline-block; padding: 14px 28px; background: #7c6bc4; color: #fff; border: none; border-radius: 10px; font-size: 15px; font-weight: 700; text-decoration: none; transition: all 0.2s; }
        .claude-btn:hover { filter: brightness(1.1); transform: translateY(-1px); }

        .playbook { display: flex; flex-direction: column; margin-bottom: 28px; }
        .play { display: flex; gap: 16px; padding: 20px 0; border-bottom: 1px solid #e4ddd4; }
        .play:last-child { border-bottom: none; }
        .play.highlight { background: linear-gradient(135deg, rgba(201,148,74,0.08), rgba(34,197,94,0.06)); border: 1px solid rgba(201,148,74,0.25); border-radius: 12px; padding: 20px; margin: 8px 0; border-bottom: none; }
        .play-number { width: 32px; height: 32px; background: #c9944a; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 14px; font-weight: 700; flex-shrink: 0; margin-top: 2px; }
        .play-number.upgrade { background: linear-gradient(135deg, #c9944a, #22c55e); font-size: 16px; width: 36px; height: 36px; }
        .play-content { flex: 1; }
        .play-content h4 { font-size: 15px; font-weight: 700; color: #2c2420; margin: 0 0 6px; }
        .play-content p { font-size: 14px; color: #6b5e52; margin: 0; line-height: 1.6; }
        .play-link { display: inline-block; margin-top: 8px; font-size: 13px; color: #7c6bc4; text-decoration: none; font-weight: 600; }
        .play-link:hover { text-decoration: underline; }

        @media (max-width: 768px) {
          .page-header { padding: 16px 20px; flex-direction: column; gap: 12px; align-items: flex-start; }
          .page-content { padding: 20px; }
          .toolkit-grid { grid-template-columns: repeat(2, 1fr); }
          .hero-earnings-banner { padding: 24px 20px; }
          .hero-earnings-stats { width: 100%; justify-content: center; }
          .tabs-bar { overflow-x: auto; -webkit-overflow-scrolling: touch; }
          .tab-btn { padding: 10px 14px; font-size: 13px; white-space: nowrap; }
          .content-card { padding: 20px; }
          .claude-header-row { flex-direction: column; }
        }
      `}</style>
    </div>
  )
}
