'use client';

import { useState } from 'react';
import type { Vendor } from '@/lib/types';

interface Props {
  vendor: Vendor;
  links: { affiliateLink: string };
  showToast: (msg: string) => void;
}

export function ContactSection({ vendor, links, showToast }: Props) {
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: '', email: '', phone: '',
    event_date: '', interest: '', message: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, vendor_id: vendor.id }),
      });

      if (res.ok) {
        showToast('Message sent! We\'ll be in touch soon.');
        setForm({ name: '', email: '', phone: '', event_date: '', interest: '', message: '' });
      } else {
        showToast('Something went wrong. Please try again.');
      }
    } catch {
      showToast('Network error. Please try again.');
    }
    setSubmitting(false);
  };

  const location = [vendor.city, vendor.state].filter(Boolean).join(', ');
  
  // Clean up Instagram handle - remove full URL if present
  const getInstagramHandle = (handle?: string) => {
    if (!handle) return null;
    const cleaned = handle
      .replace(/^https?:\/\/(www\.)?instagram\.com\//i, '')
      .replace(/\/$/, '')
      .replace(/^@/, '');
    return `@${cleaned}`;
  };

  const instagramHandle = getInstagramHandle(vendor.instagram_handle);
  const interestOptions = getInterestOptions(vendor.category);

  return (
    <section id="contact" className="section">
      <div className="section-header">
        <span className="section-label">Get in Touch</span>
        <h2 className="section-title">Let&apos;s Plan Something Amazing</h2>
        <p className="section-subtitle">
          Ready to start planning? Reach out for a free consultation.
        </p>
      </div>

      <div className="contact-grid">
        {/* Left: Contact Info */}
        <div className="contact-info">
          <h3>Let&apos;s Talk</h3>
          <p>
            Whether you&apos;re planning a wedding, corporate event, or milestone celebration — we&apos;d love to hear about your vision. Reach out anytime for a free consultation.
          </p>

          {/* Location */}
          {location && (
            <div className="contact-item">
              <div className="contact-icon">📍</div>
              <div>
                <div className="contact-item-label">Location</div>
                <div className="contact-item-value">
                  {location}<br />
                  Serving all of New Jersey &amp; beyond
                </div>
              </div>
            </div>
          )}

          {/* Hours */}
          <div className="contact-item">
            <div className="contact-icon">🕐</div>
            <div>
              <div className="contact-item-label">Hours</div>
              <div className="contact-item-value">
                Monday – Saturday<br />
                12pm – 10pm
              </div>
            </div>
          </div>

          {/* Phone */}
          {vendor.phone && (
            <div className="contact-item">
              <div className="contact-icon">📱</div>
              <div>
                <div className="contact-item-label">Phone</div>
                <div className="contact-item-value">{vendor.phone}</div>
              </div>
            </div>
          )}

          {/* Email */}
          {vendor.email && (
            <div className="contact-item">
              <div className="contact-icon">✉️</div>
              <div>
                <div className="contact-item-label">Email</div>
                <div className="contact-item-value">
                  <a href={`mailto:${vendor.email}`}>{vendor.email}</a>
                </div>
              </div>
            </div>
          )}

          {/* Instagram */}
          {instagramHandle && (
            <div className="contact-item">
              <div className="contact-icon">📷</div>
              <div>
                <div className="contact-item-label">Instagram</div>
                <div className="contact-item-value">{instagramHandle}</div>
              </div>
            </div>
          )}
        </div>

        {/* Right: Contact Form */}
        <form onSubmit={handleSubmit} className="contact-form">
          <div className="form-row">
            <div className="form-group">
              <label>Your Name *</label>
              <input
                type="text" required
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                placeholder="Full name"
              />
            </div>
            <div className="form-group">
              <label>Email *</label>
              <input
                type="email" required
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                placeholder="you@example.com"
              />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Phone</label>
              <input
                type="tel"
                value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })}
                placeholder="(862) 555-1234"
              />
            </div>
            <div className="form-group">
              <label>Event Date</label>
              <input
                type="date"
                value={form.event_date}
                onChange={e => setForm({ ...form, event_date: e.target.value })}
              />
            </div>
          </div>
          <div className="form-group">
            <label>I&apos;m Interested In</label>
            <select
              value={form.interest}
              onChange={e => setForm({ ...form, interest: e.target.value })}
            >
              <option value="">Select an option...</option>
              {interestOptions.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Tell Us More</label>
            <textarea
              rows={4}
              value={form.message}
              onChange={e => setForm({ ...form, message: e.target.value })}
              placeholder="Share details about your event — type, guest count, venue, special requests, etc."
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="btn btn-primary"
            style={{
              width: '100%', justifyContent: 'center',
              padding: '14px', fontSize: '15px',
              opacity: submitting ? 0.7 : 1,
            }}
          >
            {submitting ? 'Sending...' : 'Send Message ✨'}
          </button>
        </form>
      </div>
    </section>
  );
}

function getInterestOptions(category?: string): string[] {
  const base = ['Something Else'];
  const categoryOptions: Record<string, string[]> = {
    'Planner': ['Wedding Planning', 'Day-of Coordination', 'DJ Services', 'Photo / Video', 'Decor & Backdrops', 'Corporate Event'],
    'Day-of Coordinator': ['Wedding Planning', 'Day-of Coordination', 'DJ Services', 'Photo / Video', 'Decor & Backdrops', 'Corporate Event'],
    'Event Planner': ['Wedding Planning', 'Day-of Coordination', 'DJ Services', 'Photo / Video', 'Decor & Backdrops', 'Balloon Designs', 'Corporate Event'],
    'Photographer': ['Wedding Photography', 'Engagement Session', 'Event Coverage', 'Portrait Session', 'Corporate Headshots'],
    'Videographer': ['Wedding Film', 'Highlight Reel', 'Event Coverage', 'Corporate Video'],
    'DJ': ['Wedding DJ', 'Corporate Event', 'Birthday Party', 'Holiday Party', 'MC Services'],
    'Caterer': ['Wedding Catering', 'Corporate Catering', 'Private Event', 'Tasting Request'],
    'Florist': ['Wedding Flowers', 'Event Florals', 'Custom Arrangement', 'Consultation'],
    'Venue': ['Wedding Venue', 'Corporate Event', 'Private Party', 'Venue Tour'],
    'Hair & Makeup': ['Bridal Beauty', 'Bridesmaid Services', 'Special Event', 'Trial Session'],
  };
  return [...(categoryOptions[category || ''] || ['Wedding Services', 'Event Services', 'Consultation']), ...base];
}
