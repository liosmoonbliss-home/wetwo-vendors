'use client'

import { useState, useEffect } from 'react'

// ============================================================
// WeTwo — Vendor Incentive Toolbox
// Integrated Dashboard Component
// Version: 1.1 — February 14, 2026
//
// Adapted from 04-vendor-toolbox.jsx for dashboard integration.
// Accepts vendorId prop from parent (dashboard page).
// ============================================================

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://pyjrnezwehagtnvhdjmq.supabase.co'
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB5anJuZXp3ZWhhZ3Rudmhkam1xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjExNzI1OTIsImV4cCI6MjA3Njc0ODU5Mn0.n_78dY7Xf3P3mfJQYXYVQGdnToZWD_ApHtNrZWN2wtg'

const tierColors: Record<string, { bg: string; text: string; accent: string }> = {
  free: { bg: '#f5f5f3', text: '#666', accent: '#c4956a' },
  starter: { bg: '#f0f7ff', text: '#1a5fb4', accent: '#3584e4' },
  pro: { bg: '#f3f0ff', text: '#613583', accent: '#9141ac' },
  elite: { bg: '#fff8e6', text: '#986a00', accent: '#e5a50a' },
}

const tierBadges: Record<string, string> = {
  free: 'Free',
  starter: 'Starter — $97/mo',
  pro: 'Pro — $197/mo',
  elite: 'Elite — $297/mo',
}

// ---- Copy Button ----
function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      const ta = document.createElement('textarea')
      ta.value = text
      document.body.appendChild(ta)
      ta.select()
      document.execCommand('copy')
      document.body.removeChild(ta)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <button
      onClick={handleCopy}
      style={{
        padding: '6px 16px',
        borderRadius: '6px',
        border: copied ? '1.5px solid #22c55e' : '1.5px solid #e4ddd4',
        background: copied ? 'rgba(34,197,94,0.08)' : '#ffffff',
        color: copied ? '#22c55e' : '#6b5e52',
        fontSize: '12px',
        fontWeight: 600,
        cursor: 'pointer',
        fontFamily: 'inherit',
        letterSpacing: '0.03em',
        minWidth: '80px',
        textAlign: 'center' as const,
        transition: 'all 0.2s',
      }}
    >
      {copied ? '✓ Copied' : label || 'Copy'}
    </button>
  )
}

// ---- Pool Math Card ----
function PoolMathCard({ vendor, poolMath }: { vendor: any; poolMath: any }) {
  if (!vendor || !poolMath) return null

  const poolPct = Math.round(vendor.total_pool * 100)
  const exampleSale = poolMath.example_sale
  const poolAmount = poolMath.pool_amount

  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(201,148,74,0.06), rgba(201,148,74,0.02))',
      borderRadius: '14px',
      padding: '24px',
      border: '1px solid rgba(201,148,74,0.2)',
      marginBottom: '20px',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
        <div>
          <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700, color: '#2c2420' }}>
            Your Pool
          </h3>
          <p style={{ margin: '4px 0 0', fontSize: '13px', color: '#6b5e52' }}>
            On a ${exampleSale} sale, your {poolPct}% pool = ${poolAmount}
          </p>
        </div>
        <span style={{
          padding: '4px 12px',
          borderRadius: '20px',
          fontSize: '11px',
          fontWeight: 700,
          textTransform: 'uppercase' as const,
          letterSpacing: '0.06em',
          background: tierColors[vendor.tier]?.bg || '#f5f5f3',
          color: tierColors[vendor.tier]?.text || '#666',
        }}>
          {tierBadges[vendor.tier] || 'Free'}
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
        {[
          { give: 5, ...poolMath.if_give_5 },
          { give: 10, ...poolMath.if_give_10 },
          { give: 15, ...poolMath.if_give_15 },
          { give: 20, ...poolMath.if_give_20 },
        ].map((tier) => (
          <div key={tier.give} style={{
            background: '#ffffff',
            borderRadius: '10px',
            padding: '14px 12px',
            textAlign: 'center' as const,
            border: '1px solid #e4ddd4',
          }}>
            <div style={{ fontSize: '11px', color: '#9a8d80', fontWeight: 600, marginBottom: '6px', textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>
              Give {tier.give}%
            </div>
            <div style={{ fontSize: '20px', fontWeight: 700, color: '#22c55e' }}>
              ${tier.vendor_keeps}
            </div>
            <div style={{ fontSize: '10px', color: '#9a8d80', marginTop: '2px' }}>
              you keep
            </div>
          </div>
        ))}
      </div>

      {vendor.tier === 'free' && (
        <div style={{
          marginTop: '16px',
          padding: '14px 18px',
          background: 'linear-gradient(135deg, rgba(34,197,94,0.06), rgba(201,148,74,0.04))',
          borderRadius: '10px',
          border: '1px solid rgba(34,197,94,0.2)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '16px',
        }}>
          <div>
            <p style={{ margin: 0, fontSize: '13px', fontWeight: 600, color: '#2c2420' }}>
              Upgrade to Starter — always keep at least 10%
            </p>
            <p style={{ margin: '2px 0 0', fontSize: '12px', color: '#6b5e52' }}>
              On that same ${exampleSale} sale giving 20%: you'd keep $50 with Starter
            </p>
          </div>
          <a href="/dashboard/earnings" style={{
            padding: '8px 20px',
            borderRadius: '8px',
            border: 'none',
            background: '#22c55e',
            color: '#fff',
            fontSize: '12px',
            fontWeight: 700,
            cursor: 'pointer',
            whiteSpace: 'nowrap' as const,
            textDecoration: 'none',
          }}>
            Upgrade →
          </a>
        </div>
      )}
    </div>
  )
}

// ---- Earnings Card ----
function EarningsCard({ earnings }: { earnings: any }) {
  if (!earnings) return null
  return (
    <div style={{
      background: '#ffffff',
      borderRadius: '14px',
      padding: '24px',
      border: '1px solid #e4ddd4',
      marginBottom: '20px',
    }}>
      <h3 style={{ margin: '0 0 16px', fontSize: '16px', fontWeight: 700, color: '#2c2420' }}>
        📊 Your Activity
      </h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
        {[
          { value: `$${Number(earnings.total_sales).toLocaleString()}`, label: 'Total Sales', color: '#2c2420' },
          { value: earnings.total_uses, label: 'Total Uses', color: '#2c2420' },
          { value: `$${Number(earnings.cashback_sales).toLocaleString()}`, label: 'Registry Sales', color: '#c9944a' },
          { value: `$${Number(earnings.coupon_sales).toLocaleString()}`, label: 'Shopper Sales', color: '#3b82f6' },
        ].map((stat) => (
          <div key={stat.label} style={{ textAlign: 'center' as const }}>
            <div style={{ fontSize: '22px', fontWeight: 800, color: stat.color }}>{stat.value}</div>
            <div style={{ fontSize: '11px', color: '#9a8d80', marginTop: '2px', textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>{stat.label}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ---- Incentive Card ----
function IncentiveCard({ item, type }: { item: any; type: 'cashback' | 'coupon' }) {
  const isLocked = item.locked
  const isCashback = type === 'cashback'

  return (
    <div style={{
      background: isLocked ? '#fafaf8' : '#ffffff',
      borderRadius: '12px',
      padding: '16px 20px',
      border: isLocked ? '1px dashed #d4cec6' : '1px solid #e4ddd4',
      opacity: isLocked ? 0.6 : 1,
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      transition: 'box-shadow 0.2s',
    }}>
      {/* Percentage badge */}
      <div style={{
        width: '52px',
        height: '52px',
        borderRadius: '12px',
        display: 'flex',
        flexDirection: 'column' as const,
        alignItems: 'center',
        justifyContent: 'center',
        background: isCashback
          ? 'linear-gradient(135deg, rgba(201,148,74,0.12), rgba(201,148,74,0.06))'
          : 'linear-gradient(135deg, rgba(59,130,246,0.12), rgba(59,130,246,0.06))',
        flexShrink: 0,
      }}>
        <span style={{ fontSize: '18px', fontWeight: 800, color: isCashback ? '#c9944a' : '#3b82f6', lineHeight: 1 }}>
          {item.percentage}%
        </span>
        <span style={{ fontSize: '8px', fontWeight: 600, color: '#9a8d80', textTransform: 'uppercase' as const, letterSpacing: '0.05em' }}>
          {isCashback ? 'back' : 'off'}
        </span>
      </div>

      {/* Info */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: '14px', fontWeight: 600, color: '#2c2420' }}>
          {item.label}
        </div>
        <div style={{ fontSize: '12px', color: '#9a8d80', marginTop: '2px' }}>
          {isLocked
            ? `Requires ${item.requires_tier} plan`
            : `You keep ${item.vendor_keeps}% · Used ${item.times_used}x`}
        </div>
        {!isLocked && (
          <div style={{
            marginTop: '6px',
            padding: '4px 10px',
            background: '#f3efe9',
            borderRadius: '4px',
            fontSize: '11px',
            fontFamily: "'Courier New', monospace",
            color: '#6b5e52',
            display: 'inline-block',
            maxWidth: '100%',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap' as const,
          }}>
            {item.code}
          </div>
        )}
      </div>

      {/* Action */}
      <div style={{ flexShrink: 0 }}>
        {isLocked ? (
          <span style={{
            padding: '6px 14px',
            borderRadius: '6px',
            border: '1.5px solid #d4cec6',
            background: '#fafaf8',
            color: '#b0a898',
            fontSize: '12px',
            fontWeight: 600,
          }}>
            🔒 Locked
          </span>
        ) : (
          <CopyButton text={item.code} label={isCashback ? 'Copy Link' : 'Copy Code'} />
        )}
      </div>
    </div>
  )
}

// ============================================================
// Demo data for preview when Supabase is unavailable
// ============================================================
const DEMO_DATA = {
  vendor: {
    id: 1,
    name: 'Rebell Entertainment',
    tier: 'free',
    tier_name: 'Free',
    total_pool: 0.2,
    min_vendor_keep: 0,
    has_branded_store: false,
    price_monthly: 0,
  },
  cashback_links: [
    { id: 1, percentage: 10, code: 'https://wetwo.love/?ref=vendor-rebell-entertainment-tld0&cb=10', label: 'Bride Registry - 10% Cashback', description: 'Share with brides who create a registry.', requires_tier: 'free', is_active: true, times_used: 12, total_sales: 2400.0, last_used_at: '2026-02-10', locked: false, vendor_keeps: 10 },
    { id: 2, percentage: 15, code: 'https://wetwo.love/?ref=vendor-rebell-entertainment-tld0&cb=15', label: 'Bride Registry - 15% Cashback', description: 'Share with brides who create a registry.', requires_tier: 'free', is_active: true, times_used: 8, total_sales: 1800.0, last_used_at: '2026-02-09', locked: false, vendor_keeps: 5 },
    { id: 3, percentage: 20, code: 'https://wetwo.love/?ref=vendor-rebell-entertainment-tld0&cb=20', label: 'Bride Registry - 20% Cashback', description: 'Share with VIP brides.', requires_tier: 'free', is_active: true, times_used: 3, total_sales: 900.0, last_used_at: '2026-02-08', locked: false, vendor_keeps: 0 },
    { id: 4, percentage: 25, code: 'https://wetwo.love/?ref=vendor-rebell-entertainment-tld0&cb=25', label: 'Bride Registry - 25% Cashback', description: 'Premium tier. Requires Starter plan.', requires_tier: 'starter', is_active: true, times_used: 0, total_sales: 0, last_used_at: null, locked: true, vendor_keeps: -5 },
  ],
  coupon_codes: [
    { id: 5, percentage: 5, code: 'WTHK4YN7', label: 'Shoppers - 5% Off', description: 'Instant 5% discount at checkout.', requires_tier: 'free', is_active: true, times_used: 24, total_sales: 3200.0, last_used_at: '2026-02-12', locked: false, vendor_keeps: 15 },
    { id: 6, percentage: 10, code: 'WTM3RJ8X', label: 'Shoppers - 10% Off', description: 'Instant 10% discount at checkout.', requires_tier: 'free', is_active: true, times_used: 15, total_sales: 2100.0, last_used_at: '2026-02-11', locked: false, vendor_keeps: 10 },
    { id: 7, percentage: 15, code: 'WTPQ52AV', label: 'Shoppers - 15% Off', description: 'Instant 15% discount at checkout.', requires_tier: 'free', is_active: true, times_used: 6, total_sales: 980.0, last_used_at: '2026-02-07', locked: false, vendor_keeps: 5 },
    { id: 8, percentage: 20, code: 'WT9BC6DW', label: 'Shoppers - 20% Off', description: 'Instant 20% discount at checkout.', requires_tier: 'free', is_active: true, times_used: 2, total_sales: 450.0, last_used_at: '2026-02-05', locked: false, vendor_keeps: 0 },
  ],
  earnings: {
    total_sales: 11830.0,
    total_uses: 70,
    cashback_sales: 5100.0,
    coupon_sales: 6730.0,
  },
  pool_math: {
    example_sale: 500,
    pool_amount: 100,
    if_give_5: { shopper_gets: 25, vendor_keeps: 75 },
    if_give_10: { shopper_gets: 50, vendor_keeps: 50 },
    if_give_15: { shopper_gets: 75, vendor_keeps: 25 },
    if_give_20: { shopper_gets: 100, vendor_keeps: 0 },
  },
}

// ============================================================
// Main Export
// ============================================================
export default function VendorToolbox({ vendorId }: { vendorId?: number | string }) {
  const [toolbox, setToolbox] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<'cashback' | 'coupons'>('cashback')

  useEffect(() => {
    async function fetchToolbox() {
      if (!vendorId) {
        setToolbox(DEMO_DATA)
        setLoading(false)
        return
      }
      try {
        const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/get_vendor_toolbox`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            apikey: SUPABASE_ANON_KEY,
            Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({ p_vendor_id: vendorId }),
        })

        if (!res.ok) throw new Error(`API error: ${res.status}`)
        const data = await res.json()
        setToolbox(data)
      } catch (err: any) {
        setError(err.message)
        setToolbox(DEMO_DATA)
      } finally {
        setLoading(false)
      }
    }
    fetchToolbox()
  }, [vendorId])

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '300px' }}>
        <div style={{ fontSize: '14px', color: '#9a8d80' }}>Loading your toolbox...</div>
      </div>
    )
  }

  if (!toolbox) {
    return (
      <div style={{ padding: '40px', textAlign: 'center', color: '#cc0000' }}>
        Error loading toolbox: {error}
      </div>
    )
  }

  const { vendor, cashback_links, coupon_codes, earnings, pool_math } = toolbox

  return (
    <div>
      {/* Pool Math */}
      <PoolMathCard vendor={vendor} poolMath={pool_math} />

      {/* Earnings */}
      <EarningsCard earnings={earnings} />

      {/* Tab Toggle */}
      <div style={{
        display: 'flex',
        gap: 0,
        marginBottom: '16px',
        borderRadius: '12px',
        overflow: 'hidden',
        border: '1.5px solid #e4ddd4',
      }}>
        <button
          onClick={() => setActiveTab('cashback')}
          style={{
            flex: 1,
            padding: '12px',
            border: 'none',
            background: activeTab === 'cashback' ? '#c9944a' : '#fff',
            color: activeTab === 'cashback' ? '#fff' : '#6b5e52',
            fontSize: '13px',
            fontWeight: 700,
            cursor: 'pointer',
            fontFamily: 'inherit',
            letterSpacing: '0.03em',
            transition: 'all 0.2s',
          }}
        >
          🎁 Bride Registry Links ({cashback_links?.length || 0})
        </button>
        <button
          onClick={() => setActiveTab('coupons')}
          style={{
            flex: 1,
            padding: '12px',
            border: 'none',
            borderLeft: '1.5px solid #e4ddd4',
            background: activeTab === 'coupons' ? '#3b82f6' : '#fff',
            color: activeTab === 'coupons' ? '#fff' : '#6b5e52',
            fontSize: '13px',
            fontWeight: 700,
            cursor: 'pointer',
            fontFamily: 'inherit',
            letterSpacing: '0.03em',
            transition: 'all 0.2s',
          }}
        >
          🛒 Shopper Coupon Codes ({coupon_codes?.length || 0})
        </button>
      </div>

      {/* Cashback Links Tab */}
      {activeTab === 'cashback' && (
        <div>
          <p style={{ fontSize: '13px', color: '#9a8d80', margin: '0 0 16px', lineHeight: 1.6 }}>
            Share these links with brides who create a registry through you.
            They get cashback on every gift purchased. You keep the rest of your pool.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {(cashback_links || []).map((item: any) => (
              <IncentiveCard key={item.id} item={item} type="cashback" />
            ))}
          </div>
        </div>
      )}

      {/* Coupon Codes Tab */}
      {activeTab === 'coupons' && (
        <div>
          <p style={{ fontSize: '13px', color: '#9a8d80', margin: '0 0 16px', lineHeight: 1.6 }}>
            Share these discount codes on social media, your website, or with clients.
            Shoppers get an instant discount at checkout. You keep the rest of your pool.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {(coupon_codes || []).map((item: any) => (
              <IncentiveCard key={item.id} item={item} type="coupon" />
            ))}
          </div>
        </div>
      )}

      {/* How It Works */}
      <div style={{
        marginTop: '28px',
        padding: '20px 24px',
        background: '#fafaf8',
        borderRadius: '14px',
        border: '1px solid #e4ddd4',
      }}>
        <h4 style={{ margin: '0 0 12px', fontSize: '14px', fontWeight: 700, color: '#2c2420' }}>How It Works</h4>
        <div style={{ fontSize: '13px', color: '#6b5e52', lineHeight: 1.8 }}>
          <p style={{ margin: '0 0 8px' }}>
            <strong style={{ color: '#c9944a' }}>Registry links</strong> → Share with brides who use your services. They create a wedding registry and get cashback on every gift. You keep the difference between your pool and what you give.
          </p>
          <p style={{ margin: 0 }}>
            <strong style={{ color: '#3b82f6' }}>Coupon codes</strong> → Share anywhere. Anyone can use them for an instant discount. Perfect for social media, email blasts, or as a thank-you perk. Your pool math works the same way.
          </p>
        </div>
      </div>
    </div>
  )
}
