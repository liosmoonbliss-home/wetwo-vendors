// ============================================================
// mapOnboardToVendor.ts
// ============================================================
// Translates Claude's creative output into builder state.
// NO WHITELIST — Claude picks any theme from the library,
// invents new names, or describes a mood. We always resolve.
// ============================================================

import type { Vendor, SectionId } from './types';
import { THEME_LIBRARY, findClosestTheme } from './themes';
import type { ThemeMode } from './types';

export interface OnboardResult {
  vendor: Partial<Vendor>;
  images: { url: string; selected: boolean }[];
  theme: {
    preset: string;
    primaryColor: string;
    secondaryColor: string;
    mood: string;
  } | null;
  designNotes: string;
}

/**
 * Resolve a theme name Claude returned to a real THEME_LIBRARY key.
 * Strategy: exact match → fuzzy word match → brand color match → graceful default.
 * No whitelist. No gatekeeping. Claude is free to create.
 */
function resolvePresetName(name: string, brandColor?: string, mood?: string): string {
  if (!name) return mood === 'dark' ? 'dark-luxury' : 'light-elegant';

  const normalized = name.toLowerCase().trim();

  // 1. Exact match — Claude picked a real theme
  if (THEME_LIBRARY[normalized]) return normalized;

  // 2. Fuzzy match — Claude invented something close to a real theme
  const inputWords = normalized.split(/[-_\s]+/);
  const allThemes = Object.keys(THEME_LIBRARY);
  let bestMatch = '';
  let bestScore = 0;

  for (const themeName of allThemes) {
    const themeWords = themeName.split(/[-_\s]+/);
    let score = 0;
    for (const iw of inputWords) {
      for (const tw of themeWords) {
        if (iw === tw) score += 3;           // exact word match
        else if (tw.includes(iw) || iw.includes(tw)) score += 1; // partial
      }
    }
    // Bonus for matching mood
    if (mood) {
      const themeMode = THEME_LIBRARY[themeName].mode;
      if (mood === themeMode) score += 1;
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = themeName;
    }
  }

  if (bestScore >= 2) return bestMatch;

  // 3. Brand color match — find the closest palette by hue/saturation
  if (brandColor && /^#[0-9a-fA-F]{6}$/.test(brandColor)) {
    const preferMode = (mood === 'dark' || mood === 'light') ? mood as ThemeMode : undefined;
    return findClosestTheme(brandColor, preferMode);
  }

  // 4. Mood-based default
  return mood === 'dark' ? 'dark-luxury' : 'light-elegant';
}

export function mapOnboardToVendor(claudeOutput: Record<string, unknown>): OnboardResult {
  const c = claudeOutput;

  // Hero Config
  const heroConfig = {
    headline: (c.tagline as string) || '',
    subheadline: (c.description as string) || '',
    badge: c.vendor_category_icon
      ? `${c.vendor_category_icon} ${c.vendor_category || ''}`
      : `✦ ${c.vendor_category || 'Vendor'}`,
    backgroundImage: (c.suggested_hero_image as string) || '',
    about_photo: (c.suggested_about_image as string) || '',
    about_title: (c.about_title as string) || '',
    heroStyle: (c.hero_style as string) || 'editorial',
    accentWord: (c.accent_word as string) || undefined,
    heroTypography: (c.hero_typography as string) || 'mixed',
    heroMood: (c.hero_mood as string) || '',
  };

  // Services
  const services = Array.isArray(c.services)
    ? (c.services as Array<Record<string, string>>).map(s => ({
        icon: s.icon || '✦',
        name: s.name || '',
        description: s.description || '',
      }))
    : [];

  // Packages
  const packages = Array.isArray(c.packages)
    ? (c.packages as Array<Record<string, unknown>>).map((p, i) => ({
        id: Number((p.id as string)?.replace(/\D/g, '')) || i + 1,
        icon: (p.icon as string) || '📦',
        name: (p.name as string) || `Package ${i + 1}`,
        price: (p.price as string) || 'Contact for Pricing',
        description: (p.description as string) || '',
        features: Array.isArray(p.features) ? p.features as string[] : [],
      }))
    : [];

  // Contact info
  const contact = (c.contact_info || {}) as Record<string, string>;

  // Instagram cleanup
  let instagram = contact.instagram || '';
  if (instagram.startsWith('@')) instagram = instagram.slice(1);
  if (instagram.includes('instagram.com/')) {
    instagram = instagram.split('instagram.com/').pop()?.replace(/\/$/, '') || '';
  }

  // Gallery images
  const galleryImages = Array.isArray(c.suggested_gallery_images)
    ? (c.suggested_gallery_images as string[])
    : [];

  // Section activation
  const activeSections = buildActiveSections(c);
  const sectionOrder = Array.isArray(c.section_order)
    ? (c.section_order as string[])
    : activeSections;

  // Trust badges
  const trustBadges = Array.isArray(c.trust_badges) ? c.trust_badges : [];

  // Theme recommendation — NO WHITELIST, resolve freely
  const themeRec = c.theme_recommendation as Record<string, string> | undefined;
  let theme: OnboardResult['theme'] = null;
  let resolvedPreset = 'light-elegant';

  if (themeRec) {
    resolvedPreset = resolvePresetName(
      themeRec.preset || '',
      themeRec.primary_color,
      themeRec.mood
    );
    theme = {
      preset: resolvedPreset,
      primaryColor: themeRec.primary_color || '',
      secondaryColor: themeRec.secondary_color || '',
      mood: themeRec.mood || 'light',
    };
  }

  // Event types
  const eventTypes = Array.isArray(c.event_types)
    ? (c.event_types as string[]).map(e => typeof e === 'string' ? { icon: '💍', name: e } : e)
    : [{ icon: '💍', name: 'Weddings' }];

  // Build vendor data
  const vendor: Partial<Vendor> = {
    business_name: (c.business_name as string) || '',
    contact_name: (c.contact_name as string) || '',
    category: (c.vendor_category as string) || '',
    bio: (c.about_bio as string) || '',
    email: contact.email || '',
    phone: contact.phone || '',
    website: contact.website || '',
    instagram_handle: instagram,
    city: contact.city || '',
    state: contact.state || '',
    photo_url: (c.suggested_hero_image as string) || '',
    portfolio_images: galleryImages,
    services_included: services,
    pricing_packages: packages,
    hero_config: heroConfig,
    active_sections: activeSections as SectionId[],
    section_order: sectionOrder as SectionId[],
    event_types: eventTypes,
    trust_badges: trustBadges as Array<{ icon: string; text: string }>,
    // Theme auto-apply — resolved to a real THEME_LIBRARY key
    theme_preset: resolvedPreset,
    brand_color: theme?.primaryColor || '',
    brand_color_secondary: theme?.secondaryColor || '',
  };

  // Image selections for builder image tab
  const allImages = new Set<string>();
  if (c.suggested_hero_image) allImages.add(c.suggested_hero_image as string);
  if (c.suggested_about_image) allImages.add(c.suggested_about_image as string);
  galleryImages.forEach(img => allImages.add(img));

  const images = [...allImages].map(url => ({ url, selected: true }));

  return { vendor, images, theme, designNotes: (c.design_notes as string) || '' };
}

function buildActiveSections(c: Record<string, unknown>): string[] {
  if (Array.isArray(c.active_sections) && c.active_sections.length > 0) {
    return c.active_sections as string[];
  }
  const sections: string[] = ['hero'];
  if (c.about_bio) sections.push('about');
  if (Array.isArray(c.services) && c.services.length > 0) sections.push('services_list');
  if (Array.isArray(c.suggested_gallery_images) && c.suggested_gallery_images.length > 0) sections.push('gallery');
  if (Array.isArray(c.packages) && c.packages.length > 0) sections.push('packages');
  sections.push('contact');
  return sections;
}
