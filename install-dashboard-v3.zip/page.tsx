'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import VendorToolbox from '@/components/VendorToolbox'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts'

// ============================================================
// WeTwo — Vendor Dashboard v3
// Cockpit, not pitch deck. Understand in 5 seconds, use in 10.
// ============================================================

const TIER_INFO: Record<string, { pool: number; price: number; label: string; color: string }> = {
  free:    { pool: 20, price: 0,   label: 'Free',    color: '#6b5e52' },
  starter: { pool: 30, price: 97,  label: 'Starter', color: '#3584e4' },
  pro:     { pool: 35, price: 197, label: 'Pro',     color: '#9141ac' },
  elite:   { pool: 40, price: 297, label: 'Elite',   color: '#e5a50a' },
}

function generateEarningsData() {
  const data = []
  for (let sales = 0; sales <= 30; sales++) {
    data.push({
      sales,
      starter: Math.max(sales * 15 - 97, -97),
      pro: Math.max(sales * 22.5 - 197, -197),
      elite: Math.max(sales * 30 - 297, -297),
    })
  }
  return data
}
const earningsData = generateEarningsData()

// ---- Earnings Chart (for sidebar page) ----
function EarningsChart() {
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload) return null
    return (
      <div style={{ background: '#2c2420', borderRadius: '10px', padding: '14px 18px', boxShadow: '0 8px 24px rgba(0,0,0,0.2)' }}>
        <p style={{ margin: '0 0 8px', fontSize: '13px', fontWeight: 700, color: '#fff' }}>{label} sales/mo × $150</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ margin: '2px 0', fontSize: '12px', color: p.color }}>
            <span style={{ fontWeight: 700 }}>{p.name}:</span>{' '}
            <span style={{ fontWeight: 800 }}>${p.value.toFixed(0)}</span>
            {p.value > 0 ? '/mo profit' : ''}
          </p>
        ))}
      </div>
    )
  }

  return (
    <div>
      <ResponsiveContainer width="100%" height={280}>
        <LineChart data={earningsData} margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0ece6" />
          <XAxis dataKey="sales" tick={{ fontSize: 11, fill: '#9a8d80' }}
            label={{ value: 'Sales per month', position: 'insideBottom', offset: -2, fontSize: 12, fill: '#9a8d80' }} />
          <YAxis tick={{ fontSize: 11, fill: '#9a8d80' }} tickFormatter={(v: number) => `$${v}`}
            label={{ value: 'Monthly profit', angle: -90, position: 'insideLeft', offset: 10, fontSize: 12, fill: '#9a8d80' }} />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine y={0} stroke="#e4ddd4" strokeWidth={2} />
          <Line type="monotone" dataKey="starter" name="Starter $97/mo" stroke="#3584e4" strokeWidth={2.5} dot={false} activeDot={{ r: 5 }} />
          <Line type="monotone" dataKey="pro" name="Pro $197/mo" stroke="#9141ac" strokeWidth={2.5} dot={false} activeDot={{ r: 5 }} />
          <Line type="monotone" dataKey="elite" name="Elite $297/mo" stroke="#e5a50a" strokeWidth={3} dot={false} activeDot={{ r: 6 }} />
          <Legend verticalAlign="top" height={36} formatter={(v: string) => <span style={{ fontSize: '12px', color: '#6b5e52', fontWeight: 600 }}>{v}</span>} />
        </LineChart>
      </ResponsiveContainer>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px', marginTop: '16px' }}>
        {[
          { tier: 'Starter', profit: 20 * 15 - 97, rate: '$15', color: '#3584e4' },
          { tier: 'Pro', profit: 20 * 22.5 - 197, rate: '$22.50', color: '#9141ac' },
          { tier: 'Elite', profit: 20 * 30 - 297, rate: '$30', color: '#e5a50a' },
        ].map(p => (
          <div key={p.tier} style={{
            textAlign: 'center' as const, padding: '12px', borderRadius: '10px',
            background: `${p.color}08`, border: `1px solid ${p.color}20`,
          }}>
            <div style={{ fontSize: '10px', color: '#9a8d80', fontWeight: 700, textTransform: 'uppercase' as const }}>{p.tier} at 20 sales</div>
            <div style={{ fontSize: '20px', fontWeight: 800, color: p.color }}>${p.profit.toFixed(0)}/mo</div>
            <div style={{ fontSize: '10px', color: '#6b5e52' }}>{p.rate}/sale after break-even</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ============================================================
// MAIN DASHBOARD
// ============================================================
export default function DashboardHome() {
  const [vendor, setVendor] = useState<any>(null)
  const [stats, setStats] = useState({ totalCommission: 0, couples: 0, shoppers: 0 })
  const [sidebarPage, setSidebarPage] = useState<string | null>(null)

  useEffect(() => {
    const stored = localStorage.getItem('wetwo_vendor_session')
    if (stored) {
      const v = JSON.parse(stored)
      setVendor(v)
      fetch(`/api/dashboard/stats?ref=${v.ref}`)
        .then(r => r.json())
        .then(d => { if (d.stats) setStats(d.stats) })
        .catch(() => {})
    }
  }, [])

  if (!vendor) return null

  const firstName = (vendor.contact_name || vendor.business_name || '').split(' ')[0]
  const tier = vendor.boost_tier || vendor.plan || 'free'
  const t = TIER_INFO[tier] || TIER_INFO.free

  // If a sidebar page is selected, show that instead
  if (sidebarPage) {
    return (
      <div>
        <header className="dash-header">
          <button onClick={() => setSidebarPage(null)} className="back-btn">← Back to Dashboard</button>
        </header>
        <div className="page-content">
          {sidebarPage === 'how-it-works' && <HowItWorks pool={t.pool} />}
          {sidebarPage === 'grow' && <GrowYourBusiness tier={tier} />}
          {sidebarPage === 'playbook' && <Playbook />}
        </div>
        <style jsx>{sharedStyles}</style>
      </div>
    )
  }

  return (
    <div>
      {/* ===== HEADER — one line ===== */}
      <header className="dash-header">
        <div>
          <h1 className="dash-title">Welcome, {firstName}</h1>
          <p className="dash-sub">
            You earn <strong>{t.pool}%</strong> on every sale.
            {stats.totalCommission > 0 && <> So far: <strong style={{ color: '#22c55e' }}>${stats.totalCommission.toFixed(0)}</strong></>}
          </p>
        </div>
        <Link href={`/vendor/${vendor.ref}`} target="_blank" className="view-page-btn">View Store →</Link>
      </header>

      <div className="page-content">

        {/* ===== THE TWO MOVES — visual explainer ===== */}
        <div className="two-moves">
          <div className="move-card">
            <div className="move-icon">🎁</div>
            <div className="move-title">Couples</div>
            <div className="move-desc">Share a registry link → bride gets cashback on every gift → you earn</div>
          </div>
          <div className="move-divider">+</div>
          <div className="move-card">
            <div className="move-icon">🛒</div>
            <div className="move-title">Everyone Else</div>
            <div className="move-desc">Generate a discount code → they save at checkout → you earn</div>
          </div>
        </div>

        {/* ===== TOOLBOX — the actual tools ===== */}
        <VendorToolbox vendorRef={vendor.ref} tier={tier} />

        {/* ===== LEARN MORE — links to deeper content ===== */}
        <div className="learn-more">
          <button onClick={() => setSidebarPage('how-it-works')} className="learn-link">
            <span>💡</span> How it works
          </button>
          <button onClick={() => setSidebarPage('grow')} className="learn-link grow">
            <span>📈</span> Grow your business
          </button>
          <button onClick={() => setSidebarPage('playbook')} className="learn-link">
            <span>📋</span> Your first week
          </button>
        </div>

      </div>

      <style jsx>{sharedStyles}</style>
    </div>
  )
}

// ============================================================
// SUB-PAGES (accessible from "Learn More" links)
// ============================================================

function HowItWorks({ pool }: { pool: number }) {
  return (
    <div className="sub-page">
      <h2>💡 How it works</h2>
      <p>Every product is priced at or below market. We don't make margin — we make memberships, like Costco for small businesses.</p>
      <p>You earn <strong style={{ color: '#22c55e' }}>{pool}% on everything sold</strong> through your store. That pool is yours to keep or share as incentives up to 20%.</p>

      <h3>For couples</h3>
      <p>Give a bride your registry link. She creates a registry. 150 guests buy gifts at $150 average. She gets cashback on every one. Every guest sees your name. You earn your pool on every sale.</p>

      <h3>For everyone else</h3>
      <p>Generate a discount code. Share it on social, text it to clients, hand it out at events. They get a real discount at checkout. You earn your pool minus whatever you gave.</p>

      <h3>The generosity math</h3>
      <p>The more you give, the more people use your links. The more they use your links, the more you sell. Generosity isn't charity — it's the growth engine.</p>
    </div>
  )
}

function GrowYourBusiness({ tier }: { tier: string }) {
  return (
    <div className="sub-page">
      <h2>📈 Grow your business</h2>
      <p>Break-even is 7–10 sales for every tier. After that, higher tiers earn faster — Elite at <strong>double</strong> the rate of Starter.</p>

      <EarningsChart />

      <div style={{ marginTop: '24px' }}>
        <h3>The math at maximum generosity (giving 20%)</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '12px' }}>
          {[
            { name: 'Free', price: 0, keep: 0, note: 'Pure generosity. Build your list.', color: '#6b5e52' },
            { name: 'Starter $97/mo', price: 97, keep: 10, note: '7 gifts to break even. Then $15/gift profit.', color: '#3584e4' },
            { name: 'Pro $197/mo', price: 197, keep: 15, note: '9 gifts to break even. Then $22.50/gift.', color: '#9141ac' },
            { name: 'Elite $297/mo', price: 297, keep: 20, note: '10 gifts to break even. Then $30/gift — double Starter.', color: '#e5a50a' },
          ].map(p => (
            <div key={p.name} style={{
              padding: '14px 18px', borderRadius: '10px',
              background: `${p.color}08`, border: `1px solid ${p.color}25`,
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <div>
                <span style={{ fontWeight: 700, color: '#2c2420', fontSize: '14px' }}>{p.name}</span>
                <span style={{ color: '#6b5e52', fontSize: '13px', marginLeft: '12px' }}>{p.note}</span>
              </div>
              <span style={{ fontWeight: 700, color: '#22c55e', fontSize: '14px' }}>
                {p.keep > 0 ? `Keep ${p.keep}%` : 'Keep $0'}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div style={{
        marginTop: '24px', padding: '20px', borderRadius: '12px',
        background: 'rgba(229,165,10,0.06)', border: '1px solid rgba(229,165,10,0.2)',
        textAlign: 'center' as const,
      }}>
        <p style={{ margin: 0, fontSize: '16px', fontWeight: 600, color: '#2c2420', fontFamily: "'Playfair Display', Georgia, serif" }}>
          One wedding. 150 guests. Elite tier giving 20%:<br/>
          <span style={{ fontSize: '28px', color: '#22c55e' }}>$4,500 profit.</span>
        </p>
      </div>

      {tier === 'free' && (
        <div style={{ marginTop: '24px' }}>
          <h3>Paid tier benefits</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginTop: '8px' }}>
            {[
              'Your branding — no WeTwo',
              'Bigger pool on every sale',
              'Add your own products & services',
              'Incentives apply to everything',
              'Give 20% and still profit',
              'Featured collection spot',
            ].map((b, i) => (
              <div key={i} style={{ fontSize: '13px', color: '#6b5e52', display: 'flex', gap: '6px' }}>
                <span style={{ color: '#22c55e' }}>✓</span> {b}
              </div>
            ))}
          </div>
          <div style={{ marginTop: '16px', textAlign: 'center' as const }}>
            <Link href="/dashboard/earnings" style={{
              display: 'inline-block', padding: '12px 28px', background: '#22c55e', color: '#fff',
              borderRadius: '10px', fontSize: '15px', fontWeight: 700, textDecoration: 'none',
            }}>Upgrade Now →</Link>
          </div>
        </div>
      )}
    </div>
  )
}

function Playbook() {
  return (
    <div className="sub-page">
      <h2>📋 Your first week</h2>
      {[
        { num: '1', title: 'Shop your own store', desc: 'Buy something. Feel the experience from the customer side.' },
        { num: '2', title: 'Text 5 past clients', desc: '"I have something to share — exclusive savings on thousands of products. Want the link?"' },
        { num: '3', title: 'Generate your first code', desc: 'Pick 10% or 15%, send it to your best contacts. Watch the orders.' },
        { num: '4', title: 'Post on Instagram', desc: '"I have a gift for you 🎁 DM me GIFT for exclusive access." Every DM = a warm lead.' },
        { num: '5', title: 'Set up one registry', desc: 'One bride. 150 guests. Thousands in cashback for the couple. Hundreds of impressions for you.' },
      ].map((step, i) => (
        <div key={i} style={{ display: 'flex', gap: '14px', padding: '14px 0', borderBottom: i < 4 ? '1px solid #e4ddd4' : 'none' }}>
          <div style={{
            width: '28px', height: '28px', background: '#c9944a', borderRadius: '50%',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff', fontSize: '13px', fontWeight: 700, flexShrink: 0,
          }}>{step.num}</div>
          <div>
            <h4 style={{ margin: '0 0 3px', fontSize: '14px', fontWeight: 700, color: '#2c2420' }}>{step.title}</h4>
            <p style={{ margin: 0, fontSize: '13px', color: '#6b5e52', lineHeight: 1.5 }}>{step.desc}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

// ============================================================
// SHARED STYLES
// ============================================================
const sharedStyles = `
  .dash-header { background: #fff; border-bottom: 1px solid #e4ddd4; padding: 16px 28px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 50; }
  .dash-title { font-size: 18px; font-weight: 700; color: #2c2420; margin: 0; }
  .dash-sub { font-size: 13px; color: #6b5e52; margin: 3px 0 0; }
  .dash-sub strong { color: #2c2420; }
  .view-page-btn { padding: 7px 14px; border: 1px solid #e4ddd4; border-radius: 8px; color: #6b5e52; text-decoration: none; font-size: 13px; font-weight: 600; transition: all 0.2s; }
  .view-page-btn:hover { border-color: #c9944a; color: #c9944a; }
  .back-btn { background: none; border: none; color: #c9944a; font-weight: 600; font-size: 14px; cursor: pointer; padding: 0; font-family: inherit; }
  .back-btn:hover { text-decoration: underline; }
  .page-content { padding: 24px 28px; max-width: 800px; }

  .two-moves { display: flex; align-items: center; gap: 16px; margin-bottom: 20px; }
  .move-card { flex: 1; background: #fff; border: 1px solid #e4ddd4; border-radius: 14px; padding: 18px; text-align: center; }
  .move-icon { font-size: 28px; margin-bottom: 6px; }
  .move-title { font-size: 15px; font-weight: 700; color: #2c2420; margin-bottom: 4px; }
  .move-desc { font-size: 12px; color: #9a8d80; line-height: 1.5; }
  .move-divider { font-size: 20px; font-weight: 700; color: #d4cec6; flex-shrink: 0; }

  .learn-more { display: flex; gap: 10px; margin-top: 20px; }
  .learn-link { flex: 1; background: #fff; border: 1px solid #e4ddd4; border-radius: 10px; padding: 14px; text-align: center; font-size: 13px; font-weight: 600; color: #6b5e52; cursor: pointer; transition: all 0.2s; display: flex; align-items: center; justify-content: center; gap: 6px; font-family: inherit; }
  .learn-link:hover { border-color: #c9944a; color: #c9944a; transform: translateY(-1px); }
  .learn-link.grow { background: rgba(34,197,94,0.04); border-color: rgba(34,197,94,0.2); color: #22c55e; font-weight: 800; }
  .learn-link.grow:hover { background: rgba(34,197,94,0.08); }

  .sub-page { max-width: 700px; }
  .sub-page h2 { font-family: 'Playfair Display', Georgia, serif; font-size: 22px; color: #2c2420; margin: 0 0 16px; }
  .sub-page h3 { font-size: 16px; font-weight: 700; color: #2c2420; margin: 24px 0 8px; }
  .sub-page p { font-size: 15px; color: #6b5e52; line-height: 1.7; margin: 0 0 12px; }
  .sub-page p strong { color: #2c2420; }

  @media (max-width: 768px) {
    .dash-header { padding: 14px 20px; flex-direction: column; gap: 10px; align-items: flex-start; }
    .page-content { padding: 20px; }
    .two-moves { flex-direction: column; }
    .move-divider { transform: rotate(90deg); }
    .learn-more { flex-direction: column; }
  }
`
